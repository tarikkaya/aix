import React, { useState, useCallback, useMemo, useEffect, useRef } from 'react';
import { Page, Unit, ChatMessage, KnowledgeBase, ToDo, ToDoStatus, Variable, ApiCallAction, ToDoAction } from './types';
import Sidebar from './components/Sidebar';
import ChatView from './components/ChatView';
import CoalitionView from './components/CoalitionView';
import SettingsView from './components/SettingsView';
import UnitModal from './components/UnitModal';
import KnowledgeBasesView from './components/KnowledgeBasesView';
import KnowledgeBaseModal from './components/KnowledgeBaseModal';
import DocumentWorkspaceView from './components/DocumentWorkspaceView';
import ApiCallModal from './components/ApiCallModal';
import { LLM_PROVIDERS, EMBEDDING_PROVIDERS, STT_PROVIDERS, TTS_PROVIDERS, VECTOR_DATABASES } from './lib/constants';

// Helper to generate unique IDs
const generateId = (prefix: string) => `${prefix}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = error => reject(error);
    });
};

const textFileToString = (file: File): Promise<string> => {
     return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsText(file);
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = error => reject(error);
    });
}


const App: React.FC = () => {
  // Page and Modal State
  const [activePage, setActivePage] = useState<Page | string>(Page.CHAT);
  const [editingUnit, setEditingUnit] = useState<Unit | null>(null);
  const [editingKb, setEditingKb] = useState<KnowledgeBase | null>(null);
  const [editingApiCall, setEditingApiCall] = useState<ToDo | null>(null);

  // Chat State
  const [isProcessing, setIsProcessing] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  
  // Provider and Settings State
  const [llmProvider, setLlmProvider] = useState(LLM_PROVIDERS[0].value);
  const [llmProviderSettings, setLlmProviderSettings] = useState<any>({});
  const [sttProvider, setSttProvider] = useState<string>(STT_PROVIDERS[0].value);
  const [sttProviderSettings, setSttProviderSettings] = useState<any>({});
  const [ttsProvider, setTtsProvider] = useState<string>(TTS_PROVIDERS[0].value);
  const [ttsProviderSettings, setTtsProviderSettings] = useState<any>({});

  // Voice and Audio State
  const [availableMicrophones, setAvailableMicrophones] = useState<MediaDeviceInfo[]>([]);
  const [selectedMicrophone, setSelectedMicrophone] = useState<string>('');
  const [pushToTalkKey, setPushToTalkKey] = useState<string>('');
  const [isRecording, setIsRecording] = useState(false);

  // Core Data State
  const [units, setUnits] = useState<Unit[]>([
    // Planning Coalition
    {
      id: 'manager',
      label: 'Coalition Manager',
      enabled: true,
      prompt: `You are the Coalition Manager. Your goal is to analyze the user's request and create a "To-Do" list in JSON format to achieve it.
You have a team of specialist units and a set of available tools. Your primary job is to create a plan that invokes the correct unit or tool with the correct parameters.

Available Planning Units:
- {{available_planning_units}}

Available Execution Tools:
- {{available_tools}}

If the user uploads an image, you MUST use a VLM unit.
If the user uploads a document attachment, you MUST use the Document Analyzer unit.
If the user asks to perform an action on an external service, invoke the appropriate API Tool with a high-level task description.

Your final output must be a valid JSON array of To-Do items. A single step is sufficient.

Example for analyzing an attachment:
[
  {
    "id": "${generateId('todo')}", 
    "title": "Analyze attached document", 
    "action": { "type": "PROCESS_ATTACHMENT", "payload": { "unitId": "doc-analyzer", "attachment": { "name": "user_document.pdf" } } }
  }
]`,
      model: LLM_PROVIDERS[0].models[0],
      type: 'standard',
      coalition: 'planning',
      isManager: true,
      knowledgeProvider: 'none',
      knowledgeSettings: {},
      experienceProvider: 'none',
      experienceSettings: {},
    },
    {
      id: 'trainer',
      label: 'Trainer',
      enabled: true,
      prompt: 'You are the Trainer. Your role is to ensure the coalition learns from interactions and adheres to its core principles. You provide the foundational reasoning framework for all operations.',
      model: LLM_PROVIDERS[0].models[0],
      type: 'standard',
      coalition: 'planning',
      isTrainer: true,
      knowledgeProvider: 'none',
      knowledgeSettings: {},
      experienceProvider: 'none',
      experienceSettings: {},
    },
     {
      id: 'scraper',
      label: 'Scraper',
      enabled: true,
      prompt: `You are a web scraping expert. Your job is to take a URL and a user query, scrape the website, and extract relevant information to answer the query.`,
      model: LLM_PROVIDERS[0].models[0],
      type: 'standard',
      coalition: 'planning',
      knowledgeProvider: 'none',
      knowledgeSettings: {},
      experienceProvider: 'none',
      experienceSettings: {},
    },
    {
        id: 'gui-analyzer',
        label: 'GUI Analyzer',
        enabled: true,
        prompt: 'You are a user interface expert. Your task is to analyze the provided image of a graphical user interface (GUI). Describe the layout, identify all visible components (e.g., buttons, text fields, images), and explain their likely functions.',
        model: LLM_PROVIDERS[0].models[0], // A vision-capable model should be selected here
        type: 'vlm',
        coalition: 'planning',
        knowledgeProvider: 'none',
        knowledgeSettings: {},
        experienceProvider: 'none',
        experienceSettings: {},
    },
    {
      id: 'doc-analyzer',
      label: 'Document Analyzer',
      enabled: true,
      prompt: 'You are a document analysis expert. You will be given the content of a document. Your job is to read it, understand it, and answer questions about it or summarize it based on the user\'s request.',
      model: LLM_PROVIDERS[0].models[0],
      type: 'standard',
      coalition: 'planning',
      knowledgeProvider: 'none',
      knowledgeSettings: {},
      experienceProvider: 'none',
      experienceSettings: {},
    },
    // Execution Coalition
    {
      id: 'api-executor',
      label: 'API Executor',
      enabled: true,
      prompt: `You are an intelligent API execution agent. You will be given a high-level task. Your goal is to use your configured API template and, if necessary, your attached knowledge sources to fulfill this task.
1.  Analyze the task given in the 'parameters'.
2.  If the task requires information (like an ID), query your Knowledge Source to find it.
3.  Use the information to fill in any variables in your API template.
4.  Your final output must be a JSON To-Do list containing a single, fully-formed "API_CALL" action. Do not ask for confirmation.

Example Task: "Get user info for Jane Doe"
1.  You query your knowledge base for "Jane Doe" and find the ID is "user-456".
2.  Your API template is "https://myapi.com/users/{{userId}}".
3.  You generate the final API_CALL To-Do:
[
  {
    "id": "${generateId('todo')}",
    "title": "Get user data for Jane Doe",
    "action": {
      "type": "API_CALL",
      "payload": {
        "method": "GET",
        "endpoint": "https://myapi.com/users/user-456"
      }
    }
  }
]`,
      model: LLM_PROVIDERS[0].models[0],
      type: 'api_tool',
      coalition: 'execution',
      apiToolPayload: { method: 'GET', endpoint: 'https://api.example.com/users/{{userId}}' },
      knowledgeProvider: 'none',
      knowledgeSettings: {},
      experienceProvider: 'none',
      experienceSettings: {},
    },
    {
      id: 'final-responder',
      label: 'Final Responder',
      enabled: true,
      prompt: `You are the Final Responder. You will be given the original user request and the result of the final action (e.g., an API response). Synthesize this information into a clear, concise, and helpful message for the user.`,
      model: LLM_PROVIDERS[0].models[0],
      type: 'standard',
      coalition: 'execution',
      knowledgeProvider: 'none',
      knowledgeSettings: {},
      experienceProvider: 'none',
      experienceSettings: {},
    }
  ]);

  const [knowledgeBases, setKnowledgeBases] = useState<KnowledgeBase[]>([]);
  const [sessionVariables, setSessionVariables] = useState<Variable[]>([]);

  // === Core Handlers ===

  const handlePageChange = (page: Page | string) => {
    setActivePage(page);
  };
  
  const executeTodoList = async (todoList: ToDo[], messageId: string, depth = 0): Promise<any> => {
      if (depth > 5) {
          console.error("Max execution depth reached. Aborting.");
          return;
      }

      let lastResult: any = null;

      for (const todo of todoList) {
          const action = todo.action;
          
          setMessages(prev => prev.map(m => m.id === messageId ? {...m, todos: m.todos?.map(t => t.id === todo.id ? {...t, status: 'in-progress'} : t)} : m));
          await new Promise(resolve => setTimeout(resolve, 500)); // Simulate work
          
          if(action.type === 'INVOKE_TOOL') {
            const tool = units.find(u => u.id === action.payload.toolId);
            if (tool) {
                // Nested execution: The tool uses its own prompt to generate a new To-Do list
                console.log(`Invoking tool: ${tool.label} with params:`, action.payload.parameters);
                const toolTask = `Task: ${action.payload.parameters.task}. My template is: ${JSON.stringify(tool.apiToolPayload)}. Use my prompt to generate the final API_CALL To-Do list.`;
                
                // Simulate the tool's AI call
                await new Promise(resolve => setTimeout(resolve, 800));
                
                // This would be the response from the tool's LLM call
                const newApiCallAction: ApiCallAction = {
                    method: tool.apiToolPayload?.method || 'GET',
                    endpoint: tool.apiToolPayload?.endpoint.replace('{{userId}}', '123') || 'https://api.example.com/users/123',
                    storeResponseIn: tool.apiToolPayload?.storeResponseIn,
                    directOutput: tool.apiToolPayload?.directOutput
                };

                const newTodoList: ToDo[] = [
                    { id: generateId('todo'), title: `Execute API Call: ${tool.label}`, status: 'pending', action: { type: 'API_CALL', payload: newApiCallAction } }
                ];
                
                const toolMessageId = generateId('msg');
                setMessages(prev => [...prev, { id: toolMessageId, sender: 'todo_list', text: `${tool.label} Plan:`, todos: newTodoList }]);
                lastResult = await executeTodoList(newTodoList, toolMessageId, depth + 1);
            }
          } else if (action.type === 'API_CALL') {
            console.log('Executing API Call:', action.payload);
            lastResult = { success: true, data: { name: "Jane Doe", id: "123", email: "jane.doe@example.com"} };
          } else if (action.type === 'PROCESS_ATTACHMENT') {
            console.log('Simulating document analysis for:', action.payload.attachment.name);
            lastResult = { success: true, summary: "This is a summary of the document." };
          }
          
          const finalStatus: ToDoStatus = Math.random() > 0.1 ? 'completed' : 'failed';
          setMessages(prev => prev.map(m => m.id === messageId ? {...m, todos: m.todos?.map(t => t.id === todo.id ? {...t, status: finalStatus} : t)} : m));
      }
      return lastResult;
  };

  const handleSendMessage = async (message: string, imageFile: File | null, attachmentFile: File | null) => {
    setIsProcessing(true);
    let imageData: string | undefined = undefined;
    let attachmentData: { name: string; content: string } | undefined = undefined;
    
    if (imageFile) {
        imageData = await fileToBase64(imageFile);
    }
    if (attachmentFile) {
        const content = await textFileToString(attachmentFile);
        attachmentData = { name: attachmentFile.name, content };
    }
    
    const userMessage: ChatMessage = { id: generateId('msg'), sender: 'user', text: message, image: imageData, attachment: attachmentData };
    setMessages(prev => [...prev, userMessage]);

    // Stage 1: Planning (Manager generates a To-Do list)
    await new Promise(resolve => setTimeout(resolve, 500));
    
    // Simulate Manager's response
    let planningTodos: ToDo[];
    if (attachmentData) {
        planningTodos = [
            { id: generateId('todo'), title: `Analyze document: ${attachmentData.name}`, status: 'pending', action: { type: 'PROCESS_ATTACHMENT', payload: { unitId: 'doc-analyzer', attachment: attachmentData } } }
        ];
    } else {
        const apiTool = units.find(u => u.id === 'api-executor');
        planningTodos = [
            { id: generateId('todo'), title: `Invoke "${apiTool?.label || 'API Tool'}"`, status: 'pending', action: { type: 'INVOKE_TOOL', payload: { toolId: 'api-executor', parameters: { task: message } } } },
        ];
    }
        
    const planningMessageId = generateId('msg');
    const planningMessage: ChatMessage = { id: planningMessageId, sender: 'todo_list', text: 'Manager\'s Plan:', todos: planningTodos };
    setMessages(prev => [...prev, planningMessage]);
    
    const result = await executeTodoList(planningTodos, planningMessageId);

    // Stage 2: Final Response
    if (result) {
        const responder = units.find(u => u.id === 'final-responder');
        if (responder) {
            await new Promise(resolve => setTimeout(resolve, 500));
            const aiText = result.summary ? `Summary of document: ${result.summary}` : `Operation complete. The API returned the following data: ${JSON.stringify(result.data, null, 2)}`;
            const finalMessage: ChatMessage = {
                id: generateId('msg'),
                sender: 'ai',
                text: aiText
            };
            setMessages(prev => [...prev, finalMessage]);
        }
    }


    setIsProcessing(false);
  };


  // === CRUD Handlers ===

  const handleAddUnit = (type: 'standard' | 'rag' | 'api_tool' | 'vlm', coalition: 'planning' | 'execution') => {
    const newUnit: Unit = {
        id: generateId(type),
        label: `New ${type.replace('_', ' ').toUpperCase()} Unit`,
        enabled: true,
        prompt: `New prompt for ${type}...`,
        model: (LLM_PROVIDERS.find(p => p.value === llmProvider)?.models[0] || ''),
        type: type,
        coalition: coalition,
        apiToolPayload: type === 'api_tool' ? { method: 'GET', endpoint: 'https://api.example.com' } : undefined,
        knowledgeProvider: 'none',
        knowledgeSettings: {},
        experienceProvider: 'none',
        experienceSettings: {},
    };
    setUnits(prev => [...prev, newUnit]);
  };

  const handleUpdateUnit = (updatedUnit: Unit) => {
    setUnits(prev => prev.map(u => u.id === updatedUnit.id ? updatedUnit : u));
    setEditingUnit(null);
  };
  
  const handleDeleteUnit = (id: string) => {
    setUnits(prev => prev.filter(u => u.id !== id));
  };
  
  const handleAddKnowledgeBase = () => {
    const newKb: KnowledgeBase = {
      id: generateId('kb'),
      name: `knowledge-base-${knowledgeBases.length + 1}`,
      label: `New Knowledge Base ${knowledgeBases.length + 1}`,
      vectorProvider: VECTOR_DATABASES[1].value,
      vectorSettings: {},
      documents: [],
      embeddingProvider: EMBEDDING_PROVIDERS[0].value,
      embeddingProviderSettings: {},
      embeddingModel: '',
      embeddingChunkSize: 8192,
      chunkSize: 8192,
      chunkOverlap: 20,
    };
    setKnowledgeBases(prev => [...prev, newKb]);
  };

  const handleUpdateKnowledgeBase = (updatedKb: KnowledgeBase) => {
    setKnowledgeBases(prev => prev.map(kb => kb.id === updatedKb.id ? updatedKb : kb));
    setEditingKb(null);
  };

    const handleUpdateKnowledgeBaseSettings = (updatedKb: KnowledgeBase) => {
    setKnowledgeBases(prev => prev.map(kb => kb.id === updatedKb.id ? updatedKb : kb));
  };

  
  const handleDeleteKnowledgeBase = (id: string) => {
    setKnowledgeBases(prev => prev.filter(kb => kb.id !== id));
  };
  
  // === Settings Save Handlers ===
  const handleSaveLLMProviderSettings = (provider: string, settings: any) => {
      setLlmProvider(provider);
      setLlmProviderSettings(settings);
  };

  const handleSaveTrainerSettings = (settings: Omit<Unit, 'id' | 'label' | 'enabled' | 'model' | 'type' | 'isTrainer' | 'coalition' | 'knowledgeBaseId' | 'apiToolPayload'>) => {
      setUnits(prev => prev.map(u => u.id === 'trainer' ? {...u, ...settings} : u));
  };
  
  const handleSaveManagerPrompt = (prompt: string) => {
    setUnits(prev => prev.map(u => u.id === 'manager' ? {...u, prompt} : u));
  }

  const handleUpdateApiCall = (updatedTodo: ToDo) => {
    setMessages(prev => prev.map(m => {
        if (!m.todos) return m;
        return {
            ...m,
            todos: m.todos.map(t => t.id === updatedTodo.id ? updatedTodo : t)
        };
    }));
    setEditingApiCall(null);
  };

  // === Voice and Audio Effects ===
  useEffect(() => {
    const getMicrophones = async () => {
      try {
        await navigator.mediaDevices.getUserMedia({ audio: true }); // Request permission
        const devices = await navigator.mediaDevices.enumerateDevices();
        const audioInputDevices = devices.filter(device => device.kind === 'audioinput');
        setAvailableMicrophones(audioInputDevices);
        if (audioInputDevices.length > 0) {
          setSelectedMicrophone(audioInputDevices[0].deviceId);
        }
      } catch (err) {
        console.error('Microphone access denied:', err);
      }
    };
    getMicrophones();
  }, []);

  useEffect(() => {
    if (!pushToTalkKey) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === pushToTalkKey && !isRecording && !isProcessing) {
        e.preventDefault();
        setIsRecording(true);
      }
    };
    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.key === pushToTalkKey && isRecording) {
        e.preventDefault();
        setIsRecording(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [pushToTalkKey, isRecording, isProcessing]);

  // Derived State
  const planningUnits = useMemo(() => units.filter(u => u.coalition === 'planning'), [units]);
  const executionUnits = useMemo(() => units.filter(u => u.coalition === 'execution'), [units]);
  const manager = useMemo(() => units.find(u => u.isManager), [units])!;
  const trainer = useMemo(() => units.find(u => u.isTrainer), [units])!;
  const hasActiveVlmUnits = useMemo(() => units.some(u => u.type === 'vlm' && u.enabled), [units]);
  const hasDocumentAnalyzer = useMemo(() => units.some(u => u.id === 'doc-analyzer' && u.enabled), [units]);

  const renderActivePage = () => {
    const kb = knowledgeBases.find(k => k.id === activePage);
    if (kb) {
      return <DocumentWorkspaceView knowledgeBase={kb} />;
    }

    switch (activePage) {
      case Page.CHAT:
        return <ChatView
          messages={messages}
          onSendMessage={handleSendMessage}
          isProcessing={isProcessing}
          isRecording={isRecording}
          hasActiveVlmUnits={hasActiveVlmUnits}
          hasDocumentAnalyzer={hasDocumentAnalyzer}
          onToggleRecording={() => setIsRecording(prev => !prev)}
          onPlayAudio={(text) => console.log('Playing audio for:', text)}
          onEditApiCall={(todo) => setEditingApiCall(todo)}
        />;
      case Page.UNITS:
        return <CoalitionView 
          title="Units"
          units={planningUnits}
          onAddUnit={(type) => handleAddUnit(type, 'planning')}
          onUpdateUnit={handleUpdateUnit}
          onDeleteUnit={handleDeleteUnit}
          onEditUnit={(unit) => setEditingUnit(unit)}
          coalition="planning"
          llmProvider={LLM_PROVIDERS.find(p => p.value === llmProvider)?.name || llmProvider}
        />;
      case Page.WORK_UNITS:
        return <CoalitionView 
          title="Work Units"
          units={executionUnits}
          onAddUnit={(type) => handleAddUnit(type, 'execution')}
          onUpdateUnit={handleUpdateUnit}
          onDeleteUnit={handleDeleteUnit}
          onEditUnit={(unit) => setEditingUnit(unit)}
          coalition="execution"
          llmProvider={LLM_PROVIDERS.find(p => p.value === llmProvider)?.name || llmProvider}
        />;
      case Page.KNOWLEDGE_BASES:
          return <KnowledgeBasesView 
            knowledgeBases={knowledgeBases}
            onAddUnit={handleAddKnowledgeBase}
            onEditUnit={(kb) => setEditingKb(kb)}
            onDeleteUnit={handleDeleteKnowledgeBase}
          />;
      case Page.SETTINGS:
        return <SettingsView 
          managerPrompt={manager.prompt}
          onSaveManagerPrompt={handleSaveManagerPrompt}
          trainerUnit={trainer}
          onSaveTrainerSettings={handleSaveTrainerSettings}
          llmProvider={llmProvider}
          llmProviderSettings={llmProviderSettings}
          onSaveLLMProviderSettings={handleSaveLLMProviderSettings}
          sttProvider={sttProvider}
          sttProviderSettings={sttProviderSettings}
          onSaveSTTProviderSettings={(p, s) => { setSttProvider(p); setSttProviderSettings(s); }}
          ttsProvider={ttsProvider}
          ttsProviderSettings={ttsProviderSettings}
          onSaveTTSProviderSettings={(p, s) => { setTtsProvider(p); setTtsProviderSettings(s); }}
          knowledgeBases={knowledgeBases}
          onSaveKnowledgeBaseSettings={handleUpdateKnowledgeBaseSettings}
          availableMicrophones={availableMicrophones}
          selectedMicrophone={selectedMicrophone}
          onSelectMicrophone={setSelectedMicrophone}
          pushToTalkKey={pushToTalkKey}
          onSetPushToTalkKey={setPushToTalkKey}
        />;
      default:
        return <div className="p-6 text-center text-gray-400">Select a page from the sidebar.</div>;
    }
  };

  return (
    <div className="flex h-screen bg-dark text-white font-sans">
      <Sidebar activePage={activePage} onPageChange={handlePageChange} knowledgeBases={knowledgeBases} />
      <main className="flex-1 overflow-hidden">
        {renderActivePage()}
      </main>
      
      {editingUnit && <UnitModal 
        unit={editingUnit} 
        onClose={() => setEditingUnit(null)} 
        onSave={handleUpdateUnit} 
        models={LLM_PROVIDERS.find(p => p.value === llmProvider)?.models || []}
        knowledgeBases={knowledgeBases} 
      />}
      
      {editingKb && <KnowledgeBaseModal 
        unit={editingKb} 
        onClose={() => setEditingKb(null)} 
        onSave={handleUpdateKnowledgeBase}
      />}

      {editingApiCall && <ApiCallModal 
        todo={editingApiCall} 
        variables={sessionVariables} 
        onClose={() => setEditingApiCall(null)} 
        onSave={handleUpdateApiCall}
      />}
    </div>
  );
};

export default App;