
import React from 'react';
import { VectorDB, LLMProvider, EmbeddingProvider, DataConnector, STTProvider, TTSProvider } from '../types';
import { ChipIcon, LinkIcon, PlayCircleIcon } from '../components/icons'; // Assuming some icons exist

// A placeholder for now, you can create specific icons for each
const GithubIcon = ({ className }: { className?: string }): JSX.Element => (
    React.createElement('svg', {
        className,
        viewBox: "0 0 16 16",
        fill: "currentColor",
        'aria-hidden': "true"
    }, React.createElement('path', { d: "M8 0c4.42 0 8 3.58 8 8a8.013 8.013 0 0 1-5.45 7.59c-.4.08-.55-.17-.55-.38 0-.19.01-.82.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.28.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21-.15.46-.55.38A8.013 8.013 0 0 1 0 8c0-4.42 3.58-8 8-8Z" }))
);
const GitlabIcon = ({ className }: { className?: string }): JSX.Element => (
    React.createElement('svg', {
        className,
        viewBox: "0 0 24 24",
        fill: "currentColor"
    }, React.createElement('path', { d: "M23.955 13.587l-1.34-4.145H1.385l-1.34 4.145h23.91zM12 0L9.405 7.998h5.19L12 0zM4.65 9.442l-4.2 13.013L12 24l11.55-1.545-4.2-13.013H4.65zM9.405 7.998L12 0l2.595 7.998H9.405z" }))
);


export const LLM_PROVIDERS: LLMProvider[] = [
    {
        name: 'Google Gemini',
        value: 'gemini',
        fields: [{ name: 'apiKey', type: 'password', placeholder: 'Gemini API Key' }],
        models: ['gemini-2.5-flash', 'gemini-pro'],
    },
    {
        name: 'LMStudio',
        value: 'lmstudio',
        fields: [{ name: 'baseURL', type: 'text', placeholder: 'http://localhost:1234/v1' }],
        models: ['gemma-2b-it', 'llama3-8b-instruct', 'mistral-7b-instruct', 'provide-model-name-in-prompt'],
    },
    {
        name: 'Ollama',
        value: 'ollama',
        fields: [{ name: 'baseURL', type: 'text', placeholder: 'http://localhost:11434' }],
        models: ['llama3', 'mistral', 'gemma', 'codellama'],
    },
    {
        name: 'OpenAI',
        value: 'openai',
        fields: [{ name: 'apiKey', type: 'password', placeholder: 'OpenAI API Key' }],
        models: ['gpt-4o', 'gpt-4-turbo', 'gpt-3.5-turbo'],
    },
];

export const VECTOR_DATABASES: VectorDB[] = [
    {
        name: 'None',
        value: 'none',
        fields: [],
    },
    {
        name: 'LanceDB',
        value: 'lancedb',
        fields: [{ name: 'uri', type: 'text', placeholder: './lancedb' }],
    },
    {
        name: 'ChromaDB',
        value: 'chroma',
        fields: [
            { name: 'host', type: 'text', placeholder: 'http://localhost:8000' },
            { name: 'headers', type: 'text', placeholder: '{"Authorization": "Bearer ..."}' },
        ],
    },
    {
        name: 'Pinecone',
        value: 'pinecone',
        fields: [
            { name: 'apiKey', type: 'password', placeholder: 'Pinecone API Key' },
            { name: 'environment', type: 'text', placeholder: 'gcp-starter' },
            { name: 'index', type: 'text', placeholder: 'pinecone-index-name' },
        ],
    },
];

export const EMBEDDING_PROVIDERS: EmbeddingProvider[] = [
     {
        name: 'LM Studio',
        value: 'lmstudio',
        fields: [
            { name: 'baseURL', type: 'text', placeholder: 'http://127.0.0.1:11181/v1', info: 'Enter the URL where LM Studio is running.' },
        ],
        models: []
    },
    {
        name: 'Ollama',
        value: 'ollama',
        fields: [
            { name: 'baseURL', type: 'text', placeholder: 'http://localhost:11434' },
        ],
        models: []
    },
    {
        name: 'Google Gemini',
        value: 'gemini',
        fields: [
             { name: 'apiKey', type: 'password', placeholder: 'Gemini API Key' },
        ],
        models: ['text-embedding-004', 'text-embedding-preview-0409']
    }
];

export const STT_PROVIDERS: STTProvider[] = [
    {
        name: 'OpenAI Whisper',
        value: 'openai_whisper',
        fields: [
            { name: 'apiKey', type: 'password', placeholder: 'OpenAI API Key' }
        ],
    },
    {
        name: 'Google Speech-to-Text',
        value: 'google_stt',
        fields: [
            { name: 'apiKey', type: 'password', placeholder: 'Google Cloud API Key' }
        ],
    },
    {
        name: 'Local Whisper',
        value: 'local_whisper',
        fields: [
            {
                name: 'modelPath',
                type: 'text',
                placeholder: '/path/to/your/ggml-model.bin',
                info: 'This is the path to the model file on your local machine.',
                infoLink: {
                    text: "Download model files from Hugging Face.",
                    url: "https://huggingface.co/ggerganov/whisper.cpp/tree/main"
                }
            }
        ],
    },
];

export const TTS_PROVIDERS: TTSProvider[] = [
    {
        name: 'ElevenLabs',
        value: 'elevenlabs',
        fields: [
            { name: 'apiKey', type: 'password', placeholder: 'ElevenLabs API Key' },
            { name: 'voiceId', type: 'text', placeholder: 'Voice ID (e.g., 21m00Tcm4TlvDq8ikWAM)' },
        ],
    },
    {
        name: 'OpenAI TTS',
        value: 'openai_tts',
        fields: [
            { name: 'apiKey', type: 'password', placeholder: 'OpenAI API Key' },
            { name: 'model', type: 'select', options: ['tts-1', 'tts-1-hd'] },
            { name: 'voice', type: 'select', options: ['alloy', 'echo', 'fable', 'onyx', 'nova', 'shimmer'] },
        ],
    },
    {
        name: 'Google Text-to-Speech',
        value: 'google_tts',
        fields: [
            { name: 'apiKey', type: 'password', placeholder: 'Google Cloud API Key' },
            { name: 'voice', type: 'text', placeholder: 'e.g., en-US-Wavenet-D' },
        ],
    },
    {
        name: 'Local TTS',
        value: 'local_tts',
        fields: [
            {
                name: 'commandTemplate',
                type: 'text',
                placeholder: 'piper --model /path/to/voice.onnx --output_file - | aplay',
                info: 'The command to execute for TTS. Use {text} as a placeholder for the text to be spoken.',
            }
        ],
    },
];


export const DATA_CONNECTORS: DataConnector[] = [
    {
        name: 'GitHub Repo',
        value: 'github',
        icon: GithubIcon,
        fields: [
            { name: 'repoUrl', type: 'text', placeholder: 'https://github.com/user/repo' },
            { name: 'accessToken', type: 'password', placeholder: 'Optional Access Token', info: 'Without filling out the GitHub Access Token this data connector will only be able to collect the top-level files of the repo due to GitHubs public API rate-limits.' },
            { name: 'branch', type: 'select', options: ['main', 'master', 'develop'] },
            { name: 'fileIgnores', type: 'text', placeholder: 'e.g. node_modules, .git' },
        ]
    },
    {
        name: 'GitLab Repo',
        value: 'gitlab',
        icon: GitlabIcon,
        fields: [
            { name: 'repoUrl', type: 'text', placeholder: 'https://gitlab.com/user/repo' },
            { name: 'accessToken', type: 'password', placeholder: 'Required Access Token' },
            { name: 'branch', type: 'select', options: ['main', 'master', 'develop'] },
        ]
    },
     {
        name: 'YouTube Transcript',
        value: 'youtube',
        icon: PlayCircleIcon,
        fields: [
            { name: 'videoUrl', type: 'text', placeholder: 'https://www.youtube.com/watch?v=...' },
        ]
    },
    {
        name: 'Bulk Link Scraper',
        value: 'website',
        icon: LinkIcon,
        fields: [
            { name: 'url', type: 'text', placeholder: 'https://example.com' },
        ]
    },
];
