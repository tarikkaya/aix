export enum Page {
  CHAT = 'Chat',
  UNITS = 'Units',
  WORK_UNITS = 'Work Units',
  KNOWLEDGE_BASES = 'Knowledge Bases',
  SETTINGS = 'Settings',
}

export type ToDoStatus = 'pending' | 'in-progress' | 'completed' | 'failed';

export interface ApiCallAction {
  method: 'GET' | 'POST' | 'PUT' | 'DELETE';
  endpoint: string;
  headers?: Record<string, string>;
  body?: Record<string, any>;
  storeResponseIn?: string;
  directOutput?: boolean;
}

export type ToDoAction = 
  | { type: 'THINK'; payload: { thought: string } }
  | { type: 'SCRAPE'; payload: { url: string; query: string } }
  | { type: 'API_CALL'; payload: ApiCallAction }
  | { type: 'INVOKE_TOOL'; payload: { toolId: string; parameters: Record<string, any> } }
  | { type: 'MESSAGE'; payload: { text: string } }
  | { type: 'ANALYZE_IMAGE'; payload: { prompt: string; image: string; unitId: string } }
  | { type: 'PROCESS_ATTACHMENT'; payload: { unitId: string; attachment: { name: string; content: string } } };

export interface ToDo {
  id: string;
  title: string;
  status: ToDoStatus;
  action: ToDoAction;
}

export interface Unit {
  id: string;
  label: string;
  enabled: boolean;
  prompt: string;
  model: string;
  type: 'standard' | 'rag' | 'api_tool' | 'vlm';
  coalition: 'planning' | 'execution';
  
  // RAG specific
  knowledgeBaseId?: string;

  // API Tool specific
  apiToolPayload?: ApiCallAction;

  // Common Data Sources
  knowledgeProvider: string;
  knowledgeSettings: any;
  experienceProvider: string;
  experienceSettings: any;

  // Special flags
  isManager?: boolean;
  isCreator?: boolean;
  isTrainer?: boolean;
  onClick?: () => void;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'ai' | 'system' | 'todo_list';
  text: string;
  todos?: ToDo[];
  image?: string; // Base64 encoded image
  attachment?: { name: string; content: string };
}

export interface Document {
  id: string;
  name: string;
  type: 'file' | 'youtube' | 'website' | string;
  status: 'pending' | 'embedding' | 'complete';
}

export interface KnowledgeBase {
  id: string;
  name: string;
  label: string;
  vectorProvider: string;
  vectorSettings: any;
  documents: Document[];
  
  // Per-KB settings
  embeddingProvider: string;
  embeddingProviderSettings: any;
  embeddingModel: string;
  embeddingChunkSize: number;
  chunkSize: number;
  chunkOverlap: number;
  
  isCreator?: boolean;
  onClick?: () => void;
}

// Types for the new Provider system

export interface ProviderField {
  name: string;
  type: 'text' | 'password' | 'select';
  placeholder?: string;
  options?: string[];
  info?: string;
  infoLink?: { url: string, text: string };
}

export interface LLMProvider {
  name: string;
  value: string;
  fields: ProviderField[];
  models: string[];
}

export interface VectorDB {
  name: string;
  value: string;
  fields: ProviderField[];
}

export interface EmbeddingProvider {
  name: string;
  value: string;
  fields: ProviderField[];
  models: string[];
}

export interface STTProvider {
  name: string;
  value: string;
  fields: ProviderField[];
}

export interface TTSProvider {
  name: string;
  value: string;
  fields: ProviderField[];
}

export interface DataConnector {
  name: string;
  value: string;
  icon: (props: {className?: string}) => JSX.Element;
  fields: ProviderField[];
}

export interface Variable {
    name: string;
    value: any;
}