import React, { useState, useEffect } from 'react';
import { ApiCallAction } from '../types';
import { PlusIcon, TrashIcon } from './icons';

interface ApiToolEditorProps {
    payload: ApiCallAction;
    onPayloadChange: (payload: ApiCallAction) => void;
}

const ApiToolEditor: React.FC<ApiToolEditorProps> = ({ payload, onPayloadChange }) => {
    const [formData, setFormData] = useState<ApiCallAction>(payload);
    const [headers, setHeaders] = useState(Object.entries(payload.headers || {}));

    useEffect(() => {
        onPayloadChange({ ...formData, headers: Object.fromEntries(headers) });
    }, [formData, headers]);


    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleToggle = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, checked } = e.target;
        setFormData(prev => ({ ...prev, [name]: checked }));
    }

    const handleHeaderChange = (index: number, key: string, value: string) => {
        const newHeaders = [...headers];
        newHeaders[index] = [key, value];
        setHeaders(newHeaders);
    };

    const addHeader = () => {
        setHeaders([...headers, ['', '']]);
    };

    const removeHeader = (index: number) => {
        setHeaders(headers.filter((_, i) => i !== index));
    };


    return (
        <div className="space-y-4 pt-4 border-t border-gray-700">
            <h4 className="text-md font-semibold text-white">API Tool Configuration</h4>
            <div>
                <label htmlFor="endpoint" className="block text-sm font-medium text-gray-300">URL</label>
                <input type="text" name="endpoint" id="endpoint" value={formData.endpoint} onChange={handleChange} className="mt-1 block w-full bg-dark-light border border-gray-600 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary" />
            </div>
            <div>
                <label htmlFor="method" className="block text-sm font-medium text-gray-300">Method</label>
                <select name="method" id="method" value={formData.method} onChange={handleChange} className="mt-1 block w-full bg-dark-light border border-gray-600 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary">
                    <option>GET</option>
                    <option>POST</option>
                    <option>PUT</option>
                    <option>DELETE</option>
                </select>
            </div>
            <div>
                <div className="flex justify-between items-center mb-1">
                    <label className="block text-sm font-medium text-gray-300">Headers</label>
                    <button onClick={addHeader} className="flex items-center space-x-1 text-sm text-primary hover:text-indigo-400">
                        <PlusIcon className="w-4 h-4" />
                        <span>Add</span>
                    </button>
                </div>
                <div className="space-y-2">
                    {headers.map(([key, value], index) => (
                        <div key={index} className="flex items-center space-x-2">
                            <input type="text" value={key} onChange={(e) => handleHeaderChange(index, e.target.value, value)} placeholder="Key" className="w-1/3 bg-dark-light border border-gray-600 rounded-md py-2 px-3 text-sm focus:outline-none focus:ring-primary" />
                            <input type="text" value={value} onChange={(e) => handleHeaderChange(index, key, e.target.value)} placeholder="Value" className="flex-1 bg-dark-light border border-gray-600 rounded-md py-2 px-3 text-sm focus:outline-none focus:ring-primary" />
                            <button onClick={() => removeHeader(index)} className="p-1 text-gray-400 hover:text-red-400">
                                <TrashIcon className="w-5 h-5" />
                            </button>
                        </div>
                    ))}
                </div>
            </div>
             <div>
                <label htmlFor="storeResponseIn" className="block text-sm font-medium text-gray-300">Store Response In</label>
                <input
                    type="text"
                    name="storeResponseIn"
                    id="storeResponseIn"
                    value={formData.storeResponseIn || ''}
                    onChange={handleChange}
                    placeholder="Select or create variable (e.g., {{my_variable}})"
                    className="mt-1 block w-full bg-dark-light border border-gray-600 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary"
                />
            </div>
             <div className="flex justify-between items-center pt-2">
                <div>
                    <label htmlFor="directOutput" className="block text-sm font-medium text-white">Direct Output</label>
                    <p className="text-xs text-gray-400">Return this output directly to the chat, stopping further calls.</p>
                </div>
                 <div className="relative inline-block w-10 align-middle select-none transition duration-200 ease-in">
                    <input type="checkbox" name="directOutput" id="directOutput" checked={formData.directOutput || false} onChange={handleToggle} className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer"/>
                    <label htmlFor="directOutput" className="toggle-label block overflow-hidden h-6 rounded-full bg-gray-500 cursor-pointer"></label>
                </div>
            </div>
        </div>
    );
};

export default ApiToolEditor;