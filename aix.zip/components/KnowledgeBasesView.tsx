import React from 'react';
import { KnowledgeBase } from '../types';
import { DocumentTextIcon, PencilIcon, PlusIcon, TrashIcon } from './icons';
import { VECTOR_DATABASES } from '../lib/constants';

interface KnowledgeBaseNodeProps {
  kb: KnowledgeBase;
  onEdit: (kb: KnowledgeBase) => void;
  onDelete: (id: string) => void;
}

const KnowledgeBaseNode: React.FC<KnowledgeBaseNodeProps> = ({ kb, onEdit, onDelete }) => {
  if (kb.isCreator) {
    return (
      <button onClick={kb.onClick} className="flex flex-col items-center justify-center w-full h-full p-4 border-2 border-dashed border-gray-600 rounded-lg text-gray-400 hover:bg-secondary-light hover:border-primary hover:text-white transition-colors duration-200">
        <PlusIcon className="w-10 h-10 mb-2" />
        <span className="font-semibold">{kb.label}</span>
      </button>
    );
  }

  const vectorDb = VECTOR_DATABASES.find(db => db.value === kb.vectorProvider);

  return (
    <div className="relative flex flex-col w-full h-full p-4 border-2 bg-secondary-light border-primary rounded-lg shadow-lg">
      <div className="flex-1 flex flex-col">
        <div className="flex items-start justify-between">
          <div className="flex items-center space-x-3">
            <DocumentTextIcon className="w-6 h-6 text-primary" />
            <h4 className="font-bold text-white truncate" title={kb.label}>{kb.label}</h4>
          </div>
          <span className="text-xs font-semibold text-gray-300 bg-gray-700 px-2 py-1 rounded">{kb.name}</span>
        </div>
        <div className="mt-auto pt-4 space-y-2">
            <p className="text-sm text-gray-400">Vector Store:</p>
            <span className="text-center text-sm font-mono text-purple-400 bg-purple-900/50 px-2 py-1 rounded w-full block truncate" title={vectorDb?.name}>
              {vectorDb?.name || 'N/A'}
            </span>
        </div>
      </div>
       <div className="mt-4 pt-2 border-t border-gray-700 flex justify-end space-x-2">
        <button onClick={() => onEdit(kb)} className="px-3 py-1 text-xs font-medium text-gray-300 bg-gray-700 rounded hover:bg-gray-600">
            Edit
        </button>
        <button onClick={() => onDelete(kb.id)} className="px-3 py-1 text-xs font-medium text-red-400 bg-red-900/50 rounded hover:bg-red-900/80">
            Delete
        </button>
      </div>
    </div>
  );
};


interface KnowledgeBasesViewProps {
  knowledgeBases: KnowledgeBase[];
  onAddUnit: () => void;
  onEditUnit: (kb: KnowledgeBase) => void;
  onDeleteUnit: (id: string) => void;
}

const KnowledgeBasesView: React.FC<KnowledgeBasesViewProps> = ({ knowledgeBases, onAddUnit, onEditUnit, onDeleteUnit }) => {
  const creatorKB: KnowledgeBase = {
    id: 'creator',
    name: 'Creator',
    label: 'Add Knowledge Base',
    isCreator: true,
    onClick: onAddUnit,
    vectorProvider: 'none',
    vectorSettings: {},
    documents: [],
    embeddingProvider: '',
    embeddingProviderSettings: {},
    embeddingModel: '',
    embeddingChunkSize: 0,
    chunkSize: 0,
    chunkOverlap: 0,
  };

  return (
    <div className="flex flex-col h-full bg-dark text-white">
      <header className="px-6 py-4 border-b border-gray-700">
        <h2 className="text-xl font-semibold">Knowledge Bases</h2>
      </header>
      <main className="flex-1 p-6 overflow-y-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {knowledgeBases.map(unit => (
            <div key={unit.id} className="group aspect-square">
              <KnowledgeBaseNode kb={unit} onEdit={onEditUnit} onDelete={onDeleteUnit} />
            </div>
          ))}
          <div className="aspect-square">
            <KnowledgeBaseNode kb={creatorKB} onEdit={() => {}} onDelete={() => {}} />
          </div>
        </div>
      </main>
    </div>
  );
};

export default KnowledgeBasesView;