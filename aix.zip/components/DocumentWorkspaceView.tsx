import React, { useState } from 'react';
import { KnowledgeBase, DataConnector, ProviderField } from '../types';
import { DATA_CONNECTORS } from '../lib/constants';
import { XMarkIcon, MagnifyingGlassIcon, FolderPlusIcon, ArrowRightLeftIcon, FolderArrowDownIcon, InformationCircleIcon } from './icons';


interface DocumentWorkspaceViewProps {
  knowledgeBase: KnowledgeBase;
}

const TabButton = ({ label, isActive, onClick }: { label: string, isActive: boolean, onClick: () => void }) => (
    <button onClick={onClick} className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors duration-200 ${isActive ? 'text-white border-primary' : 'text-gray-400 border-transparent hover:text-white hover:border-gray-500'}`}>
        {label}
    </button>
);

const ConnectorForm = ({ connector }: { connector: DataConnector }) => (
    <div className="p-6 bg-secondary rounded-lg h-full">
        <h3 className="text-lg font-semibold text-white mb-4">{connector.name}</h3>
        <form className="space-y-4">
            {connector.fields.map(field => (
                <div key={field.name}>
                    <label htmlFor={field.name} className="capitalize block text-sm font-medium text-gray-300">{field.name.replace(/([A-Z])/g, ' $1')}</label>
                    {field.type === 'select' ? (
                         <select name={field.name} id={field.name} className="mt-1 block w-full bg-dark-light border border-gray-600 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm">
                           {field.options?.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                         </select>
                    ) : (
                        <input
                            type={field.type}
                            id={field.name}
                            name={field.name}
                            placeholder={field.placeholder}
                            className="mt-1 block w-full bg-dark-light border border-gray-600 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
                        />
                    )}
                    {field.info && (
                        <div className="mt-2 flex items-start space-x-2 text-xs text-gray-400 p-2 bg-blue-900/20 rounded-lg border border-blue-500/30">
                           <InformationCircleIcon className="w-4 h-4 flex-shrink-0 mt-0.5 text-blue-400" />
                           <p>{field.info}</p>
                        </div>
                    )}
                </div>
            ))}
            <div className="pt-4 flex justify-end">
                <button type="submit" className="px-6 py-2 font-semibold text-white bg-primary rounded-lg hover:bg-primary-hover">Submit</button>
            </div>
        </form>
    </div>
);


const DocumentWorkspaceView: React.FC<DocumentWorkspaceViewProps> = ({ knowledgeBase }) => {
    const [activeTab, setActiveTab] = useState('documents');
    const [activeConnector, setActiveConnector] = useState<DataConnector>(DATA_CONNECTORS[0]);

    const renderDocumentsTab = () => (
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-4 items-start">
            {/* Left Panel: My Documents */}
            <div className="bg-secondary p-4 rounded-lg flex flex-col h-full">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="text-lg font-semibold text-white">My Documents</h3>
                    <div className="flex items-center space-x-2">
                        <div className="relative">
                            <MagnifyingGlassIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                            <input type="text" placeholder="Search for document" className="bg-dark-light border border-gray-600 rounded-md py-1.5 pl-9 pr-3 w-48 text-sm focus:ring-primary focus:border-primary" />
                        </div>
                        <button className="flex items-center space-x-2 px-3 py-1.5 text-sm bg-dark-light border border-gray-600 rounded-md hover:bg-gray-700">
                            <FolderPlusIcon className="w-4 h-4" />
                            <span>New Folder</span>
                        </button>
                    </div>
                </div>
                <div className="flex-grow p-4 bg-dark-light rounded-md flex flex-col min-h-[300px]">
                    {/* Document List would go here */}
                    <div className="flex-grow flex items-center justify-center text-gray-500">No Documents</div>

                    {/* Upload area at the bottom */}
                    <div className="mt-auto pt-4 border-t border-gray-600">
                         <div className="flex items-center justify-center w-full mb-2">
                            <label htmlFor="dropzone-file" className="flex flex-col items-center justify-center w-full py-6 border-2 border-gray-600 border-dashed rounded-lg cursor-pointer bg-secondary-light hover:bg-dark-light">
                                <div className="flex flex-col items-center justify-center">
                                    <FolderArrowDownIcon className="w-8 h-8 mb-2 text-gray-400"/>
                                    <p className="text-sm text-gray-400"><span className="font-semibold">Click to upload</span> or drag and drop</p>
                                    <p className="text-xs text-gray-500">supports text files, csv's, spreadsheets, audio files, and more!</p>
                                </div>
                                <input id="dropzone-file" type="file" className="hidden" multiple />
                            </label>
                        </div>
                         <div className="text-center my-2 text-gray-500 text-sm">or submit a link</div>
                         <div className="flex space-x-2">
                            <input type="text" placeholder="https://example.com" className="flex-1 px-3 py-1.5 text-sm bg-dark-light border border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-primary" />
                            <button className="px-4 py-1.5 text-sm font-semibold text-white bg-primary rounded-lg hover:bg-primary-hover">Fetch website</button>
                        </div>
                    </div>
                </div>
                <p className="text-xs text-gray-500 mt-2 text-center">These files will be uploaded to the document processor running on this AIX instance. These files are not sent or shared with a third party.</p>
            </div>
             
             {/* Transfer Icon - only shows on larger screens */}
            <div className="hidden xl:flex items-center justify-center h-full">
                 <ArrowRightLeftIcon className="w-8 h-8 text-gray-500" />
            </div>

            {/* Right Panel: Synced Docs */}
            <div className="bg-secondary p-4 rounded-lg flex flex-col h-full">
                 <h3 className="text-lg font-semibold text-white mb-4">{knowledgeBase.label}</h3>
                 <div className="flex-grow p-4 bg-dark-light rounded-md flex items-center justify-center min-h-[300px]">
                    <span className="text-gray-500">No Documents</span>
                    {/* Synced documents list here */}
                 </div>
            </div>
        </div>
    );

    const renderDataConnectorsTab = () => (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Left: Connector List */}
            <div className="md:col-span-1 bg-secondary p-4 rounded-lg h-fit">
                 <h3 className="text-lg font-semibold text-white mb-4">Data Connectors</h3>
                 <div className="relative mb-4">
                    <MagnifyingGlassIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <input type="text" placeholder="Search data connectors" className="bg-dark-light border border-gray-600 rounded-md py-1.5 pl-9 pr-3 w-full text-sm focus:ring-primary focus:border-primary" />
                </div>
                <div className="space-y-1">
                    {DATA_CONNECTORS.map(connector => (
                        <button key={connector.value} onClick={() => setActiveConnector(connector)} className={`w-full flex items-center space-x-3 p-2 rounded-md text-left ${activeConnector.value === connector.value ? 'bg-primary text-white' : 'hover:bg-secondary-light'}`}>
                            <connector.icon className="w-5 h-5" />
                            <span className="text-sm">{connector.name}</span>
                        </button>
                    ))}
                </div>
            </div>
            {/* Right: Connector Form */}
            <div className="md:col-span-2">
                {activeConnector && <ConnectorForm connector={activeConnector} />}
            </div>
        </div>
    );

  return (
    <div className="flex flex-col h-full bg-dark text-white">
      <header className="px-6 py-4 border-b border-gray-700 flex justify-between items-center">
        <h2 className="text-xl font-semibold">
          <span className="text-gray-400">Knowledge Base:</span> {knowledgeBase.label}
        </h2>
        <div className="flex items-center space-x-1">
            <TabButton label="Documents" isActive={activeTab === 'documents'} onClick={() => setActiveTab('documents')} />
            <TabButton label="Data Connectors" isActive={activeTab === 'connectors'} onClick={() => setActiveTab('connectors')} />
        </div>
        <button onClick={() => {}} className="text-gray-400 hover:text-white">
           <XMarkIcon className="w-6 h-6" />
        </button>
      </header>
      <main className="flex-1 p-6 overflow-y-auto">
        {activeTab === 'documents' ? renderDocumentsTab() : renderDataConnectorsTab()}
      </main>
    </div>
  );
};

export default DocumentWorkspaceView;
