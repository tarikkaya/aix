import React from 'react';
import { Page, KnowledgeBase } from '../types';
import { ChatBubbleIcon, ChipIcon, WrenchScrewdriverIcon, CogIcon, DocumentTextIcon, BookOpenIcon } from './icons';

interface SidebarProps {
  activePage: Page | string;
  onPageChange: (page: Page | string) => void;
  knowledgeBases: KnowledgeBase[];
}

const NavItem = ({ icon, label, isActive, onClick, truncate = false }: { icon: React.ReactNode, label: string, isActive: boolean, onClick: () => void, truncate?: boolean }) => (
  <button
    onClick={onClick}
    className={`flex items-center w-full px-4 py-3 text-sm font-medium rounded-lg transition-colors duration-200 ${
      isActive ? 'bg-primary text-white' : 'text-gray-300 hover:bg-secondary-light hover:text-white'
    }`}
  >
    {icon}
    <span className={`ml-3 ${truncate ? 'truncate' : ''}`} title={label}>{label}</span>
  </button>
);

const Sidebar: React.FC<SidebarProps> = ({ activePage, onPageChange, knowledgeBases }) => {
  return (
    <div className="flex flex-col w-64 p-4 space-y-2 bg-secondary border-r border-gray-700 overflow-y-auto">
      <div className="flex items-center mb-6 flex-shrink-0">
        <WrenchScrewdriverIcon className="w-8 h-8 text-primary" />
        <h1 className="ml-2 text-xl font-bold text-white">AIX</h1>
      </div>
      <div className="flex-shrink-0">
        <NavItem
          icon={<ChatBubbleIcon className="w-6 h-6" />}
          label="Chat"
          isActive={activePage === Page.CHAT}
          onClick={() => onPageChange(Page.CHAT)}
        />
        <NavItem
          icon={<ChipIcon className="w-6 h-6" />}
          label="Units"
          isActive={activePage === Page.UNITS}
          onClick={() => onPageChange(Page.UNITS)}
        />
        <NavItem
          icon={<WrenchScrewdriverIcon className="w-6 h-6" />}
          label="Work Units"
          isActive={activePage === Page.WORK_UNITS}
          onClick={() => onPageChange(Page.WORK_UNITS)}
        />
        <NavItem
          icon={<BookOpenIcon className="w-6 h-6" />}
          label="Knowledge Bases"
          isActive={activePage === Page.KNOWLEDGE_BASES}
          onClick={() => onPageChange(Page.KNOWLEDGE_BASES)}
        />
      </div>

      {knowledgeBases.length > 0 && (
        <div className="pt-4 mt-4 border-t border-gray-700 flex-shrink-0">
            <h3 className="px-4 mb-2 text-xs font-semibold text-gray-400 uppercase tracking-wider">Knowledge Bases</h3>
            {knowledgeBases.map(kb => (
                 <NavItem
                    key={kb.id}
                    icon={<DocumentTextIcon className="w-5 h-5 text-gray-400" />}
                    label={kb.label}
                    isActive={activePage === kb.id}
                    onClick={() => onPageChange(kb.id)}
                    truncate
                />
            ))}
        </div>
      )}

      <div className="flex-grow" />
      <div className="flex-shrink-0">
        <NavItem
          icon={<CogIcon className="w-6 h-6" />}
          label="Settings"
          isActive={activePage === Page.SETTINGS}
          onClick={() => onPageChange(Page.SETTINGS)}
        />
      </div>
    </div>
  );
};

export default Sidebar;
