import React, { useState, useEffect } from 'react';
import { KnowledgeBase } from '../types';
import DataSourceEditor from './DataSourceEditor';

interface KnowledgeBaseModalProps {
  unit: KnowledgeBase;
  onSave: (unit: KnowledgeBase) => void;
  onClose: () => void;
}

const KnowledgeBaseModal: React.FC<KnowledgeBaseModalProps> = ({ unit, onSave, onClose }) => {
  const [formData, setFormData] = useState<KnowledgeBase | null>(null);

  useEffect(() => {
    if (unit) {
      setFormData({ ...unit });
    }
  }, [unit]);

  if (!unit || !formData) return null;

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => prev ? { ...prev, [name]: value } : null);
  };

  const handleVectorDataSourceChange = (
      provider: string,
      settings: any,
  ) => {
    setFormData(prev => {
        if (!prev) return null;
        return {
            ...prev,
            vectorProvider: provider,
            vectorSettings: settings,
        };
    });
  };

  const handleSave = () => {
    if (formData) {
      onSave(formData);
    }
  };
  
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-75 transition-opacity">
      <div className="bg-secondary rounded-lg shadow-xl w-full max-w-2xl m-4 max-h-[90vh] flex flex-col">
        <div className="px-6 py-4 border-b border-gray-700">
          <h3 className="text-lg leading-6 font-medium text-white">Edit Knowledge Base: {unit.name}</h3>
        </div>
        <div className="p-6 space-y-6 overflow-y-auto">
          <div>
            <label htmlFor="label" className="block text-sm font-medium text-gray-300">Label</label>
            <input type="text" name="label" id="label" value={formData.label} onChange={handleChange} className="mt-1 block w-full bg-secondary-light border border-gray-600 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm" />
          </div>
          
          <DataSourceEditor
            title="Vector Database"
            provider={formData.vectorProvider}
            settings={formData.vectorSettings}
            onProviderChange={handleVectorDataSourceChange}
            onSettingsChange={(newSettings) => handleVectorDataSourceChange(formData.vectorProvider, newSettings)}
          />

        </div>
        <div className="px-6 py-4 bg-dark-light border-t border-gray-700 flex justify-end space-x-3 rounded-b-lg">
          <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-gray-300 bg-secondary-light border border-gray-600 rounded-md shadow-sm hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-dark-light focus:ring-primary">Cancel</button>
          <button type="button" onClick={handleSave} className="px-4 py-2 text-sm font-medium text-white bg-primary border border-transparent rounded-md shadow-sm hover:bg-primary-hover focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-dark-light focus:ring-primary">Save Changes</button>
        </div>
      </div>
    </div>
  );
};

export default KnowledgeBaseModal;