import React from 'react';
import { Unit } from '../types';
import { TrashIcon, PencilIcon, ChipIcon, WrenchScrewdriverIcon, PlusIcon, BrainIcon, BookOpenIcon, PhotoIcon } from './icons';
import { VECTOR_DATABASES } from '../lib/constants';

interface CoalitionViewProps {
  title: string;
  units: Unit[];
  onAddUnit: (type: 'standard' | 'rag' | 'api_tool' | 'vlm') => void;
  onUpdateUnit: (unit: Unit) => void;
  onDeleteUnit: (id: string) => void;
  onEditUnit: (unit: Unit) => void;
  coalition: 'planning' | 'execution';
  llmProvider: string;
}

const UnitNode = ({ unit, onDeleteUnit, onEditUnit }: { unit: Unit, onDeleteUnit: (id:string) => void, onEditUnit: (unit: Unit) => void }) => {
    const isManager = unit.isManager;
    const isTrainer = unit.isTrainer;
    const isCreator = unit.isCreator;
    const isSpecial = isManager || isTrainer;

    const getIcon = () => {
        if (isSpecial) return isTrainer ? <BrainIcon className="w-6 h-6 text-teal-400"/> : <ChipIcon className="w-6 h-6 text-primary"/>
        switch(unit.type) {
            case 'rag': return <BookOpenIcon className="w-6 h-6 text-purple-400"/>;
            case 'api_tool': return <WrenchScrewdriverIcon className="w-6 h-6 text-orange-400" />;
            case 'vlm': return <PhotoIcon className="w-6 h-6 text-cyan-400" />;
            case 'standard':
            default:
                return <ChipIcon className="w-6 h-6 text-primary" />;
        }
    }
    
    const getCreatorIcon = () => {
         switch(unit.type) {
            case 'rag': return <BookOpenIcon className="w-10 h-10 mb-2"/>;
            case 'api_tool': return <WrenchScrewdriverIcon className="w-10 h-10 mb-2"/>;
            case 'vlm': return <PhotoIcon className="w-10 h-10 mb-2"/>;
            case 'standard':
            default:
                return <PlusIcon className="w-10 h-10 mb-2"/>;
        }
    }

    if (isCreator) {
        return (
            <button onClick={unit.onClick} className="flex flex-col items-center justify-center w-full h-full p-4 border-2 border-dashed border-gray-600 rounded-lg text-gray-400 hover:bg-secondary-light hover:border-primary hover:text-white transition-colors duration-200">
                {getCreatorIcon()}
                <span className="font-semibold">{unit.label}</span>
            </button>
        )
    }

    return (
        <div className={`relative flex flex-col w-full h-full p-4 border-2 ${isManager ? 'bg-indigo-900/50 border-indigo-500' : isTrainer ? 'bg-teal-900/50 border-teal-500' : 'bg-secondary-light'} ${unit.enabled ? (isManager ? 'border-indigo-500' : isTrainer ? 'border-teal-500' : 'border-primary') : 'border-gray-600'} rounded-lg shadow-lg transition-all duration-200 ${!unit.enabled ? 'opacity-50' : ''}`}>
            <div className="flex-1 flex flex-col">
                <div>
                    <div className="flex items-start justify-between">
                        <div className="flex items-center space-x-3">
                            {getIcon()}
                            <h4 className="font-bold text-white">{unit.label}</h4>
                        </div>
                         <div>
                            {isManager && <span className="text-xs font-semibold text-indigo-300 bg-indigo-500/50 px-2 py-1 rounded">MANAGER</span>}
                            {isTrainer && <span className="text-xs font-semibold text-teal-300 bg-teal-500/50 px-2 py-1 rounded">TRAINER</span>}
                            {unit.type === 'rag' && !isSpecial && <span className="text-xs font-semibold text-purple-300 bg-purple-500/50 px-2 py-1 rounded">RAG</span>}
                            {unit.type === 'vlm' && !isSpecial && <span className="text-xs font-semibold text-cyan-300 bg-cyan-500/50 px-2 py-1 rounded">VLM</span>}
                            {unit.type === 'api_tool' && !isSpecial && <span className="text-xs font-semibold text-orange-300 bg-orange-500/50 px-2 py-1 rounded">API TOOL</span>}
                        </div>
                    </div>
                    {unit.type === 'api_tool' ? 
                        <p className="mt-2 text-sm text-gray-400 font-mono break-all">{unit.apiToolPayload?.endpoint || 'No endpoint set.'}</p>
                        :
                        <p className="mt-2 text-sm text-gray-400 truncate h-10">{unit.prompt || 'No prompt set.'}</p>
                    }
                </div>
                <div className="mt-auto pt-2 space-y-1">
                    {unit.type !== 'api_tool' && <div className="text-center">
                        <span className="text-xs font-mono text-purple-400 bg-purple-900/50 px-2 py-1 rounded w-full block truncate" title={`Model: ${unit.model}`}>{unit.model}</span>
                    </div>}
                    {unit.type !== 'rag' && unit.type !== 'api_tool' && <div className="grid grid-cols-2 gap-x-2 text-xs">
                        <span className="text-gray-400 bg-black/20 rounded px-1 py-0.5 truncate" title={`Knowledge Provider: ${unit.knowledgeProvider}`}>
                            K: {VECTOR_DATABASES.find(db => db.value === unit.knowledgeProvider)?.name || 'N/A'}
                        </span>
                        <span className="text-gray-400 bg-black/20 rounded px-1 py-0.5 truncate" title={`Experience Provider: ${unit.experienceProvider}`}>
                            E: {VECTOR_DATABASES.find(db => db.value === unit.experienceProvider)?.name || 'N/A'}
                        </span>
                    </div>}
                </div>
            </div>
            
            <div className="mt-4 pt-2 border-t border-gray-700 flex justify-end space-x-2">
                 <button onClick={() => onEditUnit(unit)} disabled={isSpecial} className="px-3 py-1 text-xs font-medium text-gray-300 bg-gray-700 rounded hover:bg-gray-600 disabled:bg-gray-800 disabled:text-gray-500 disabled:cursor-not-allowed">
                    {isSpecial ? 'Configure in Settings' : 'Edit'}
                </button>
                {!isSpecial && <button onClick={() => onDeleteUnit(unit.id)} className="px-3 py-1 text-xs font-medium text-red-400 bg-red-900/50 rounded hover:bg-red-900/80">
                    Delete
                </button>}
            </div>
        </div>
    );
};


const CoalitionView = ({ title, units, onAddUnit, onUpdateUnit, onDeleteUnit, onEditUnit, coalition, llmProvider }: CoalitionViewProps) => {
  const creatorCards: Unit[] = [];
  
  if (coalition === 'planning') {
    creatorCards.push({
      id: 'creator-standard-planning', label: 'Add Unit', enabled: true, prompt: '', model: '',
      knowledgeProvider: 'none', knowledgeSettings: {}, experienceProvider: 'none', experienceSettings: {},
      isCreator: true, type: 'standard', coalition: 'planning', onClick: () => onAddUnit('standard'),
    });
    creatorCards.push({
      id: 'creator-rag-planning', label: 'Add RAG Unit', enabled: true, prompt: '', model: '',
      knowledgeProvider: 'none', knowledgeSettings: {}, experienceProvider: 'none', experienceSettings: {},
      isCreator: true, type: 'rag', coalition: 'planning', onClick: () => onAddUnit('rag'),
    });
    creatorCards.push({
      id: 'creator-vlm-planning', label: 'Add VLM Unit', enabled: true, prompt: '', model: '',
      knowledgeProvider: 'none', knowledgeSettings: {}, experienceProvider: 'none', experienceSettings: {},
      isCreator: true, type: 'vlm', coalition: 'planning', onClick: () => onAddUnit('vlm'),
    });
  } else { // execution
    creatorCards.push({
      id: 'creator-standard-execution', label: 'Add Work Unit', enabled: true, prompt: '', model: '',
      knowledgeProvider: 'none', knowledgeSettings: {}, experienceProvider: 'none', experienceSettings: {},
      isCreator: true, type: 'standard', coalition: 'execution', onClick: () => onAddUnit('standard'),
    });
    creatorCards.push({
        id: 'creator-api-tool-execution', label: 'Add API Tool', enabled: true, prompt: '', model: '',
        knowledgeProvider: 'none', knowledgeSettings: {}, experienceProvider: 'none', experienceSettings: {},
        isCreator: true, type: 'api_tool', coalition: 'execution', onClick: () => onAddUnit('api_tool'),
      });
  }

  return (
    <div className="flex flex-col h-full bg-dark text-white">
      <header className="px-6 py-4 border-b border-gray-700 flex justify-between items-center">
        <h2 className="text-xl font-semibold">{title}</h2>
        <div>
            <span className="mr-2 text-sm text-gray-400">LLM Provider:</span>
            <span className="font-semibold text-primary">{llmProvider}</span>
        </div>
      </header>
      <main className="flex-1 p-6 overflow-y-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {units.map(unit => (
                <div key={unit.id} className="group aspect-square">
                    <UnitNode unit={unit} onDeleteUnit={onDeleteUnit} onEditUnit={onEditUnit} />
                </div>
            ))}
            {creatorCards.map(card => (
                 <div key={card.id} className="aspect-square">
                    <UnitNode unit={card} onDeleteUnit={() => {}} onEditUnit={() => {}} />
                </div>
            ))}
        </div>
      </main>
    </div>
  );
};

export default CoalitionView;