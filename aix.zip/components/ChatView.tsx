import React, { useRef, useEffect, useState } from 'react';
import { ChatMessage, ToDo, ToDoStatus, ToDoAction } from '../types';
import { 
    ChatBubbleIcon, MicrophoneIcon, SpeakerWaveIcon, ClockIcon, 
    Cog8ToothIcon, CheckCircleIcon, XCircleIcon, LightBulbIcon, 
    GlobeAltIcon, WrenchScrewdriverIcon, PhotoIcon, XMarkIcon,
    PaperClipIcon, DocumentTextIcon
} from './icons';

interface ToDoListItemProps {
    todo: ToDo;
    onEditApiCall: (todo: ToDo) => void;
}

const getStatusIcon = (status: ToDoStatus) => {
    switch(status) {
        case 'pending': return <ClockIcon className="w-5 h-5 text-gray-500" />;
        case 'in-progress': return <Cog8ToothIcon className="w-5 h-5 text-blue-500 animate-spin" />;
        case 'completed': return <CheckCircleIcon className="w-5 h-5 text-green-500" />;
        case 'failed': return <XCircleIcon className="w-5 h-5 text-red-500" />;
        default: return <ClockIcon className="w-5 h-5 text-gray-500" />;
    }
}

const getActionIcon = (action: ToDoAction) => {
    switch(action.type) {
        case 'THINK': return <LightBulbIcon className="w-6 h-6 text-yellow-400" />;
        case 'SCRAPE': return <GlobeAltIcon className="w-6 h-6 text-cyan-400" />;
        case 'API_CALL': return <WrenchScrewdriverIcon className="w-6 h-6 text-purple-400" />;
        case 'MESSAGE': return <ChatBubbleIcon className="w-6 h-6 text-green-400" />;
        case 'ANALYZE_IMAGE': return <PhotoIcon className="w-6 h-6 text-cyan-400" />;
        case 'PROCESS_ATTACHMENT': return <DocumentTextIcon className="w-6 h-6 text-orange-400" />;
        default: return <Cog8ToothIcon className="w-6 h-6 text-gray-400" />;
    }
}

const ToDoListItem: React.FC<ToDoListItemProps> = ({ todo, onEditApiCall }) => {
    const isApiCall = todo.action.type === 'API_CALL';
    const content = (
        <>
            <div className="flex-shrink-0">{getActionIcon(todo.action)}</div>
            <div className="flex-1">
                <p className={`font-medium ${isApiCall ? 'text-purple-300' : 'text-gray-200'}`}>{todo.title}</p>
                {todo.action.type === 'THINK' && <p className="text-sm text-gray-400 italic">"{todo.action.payload.thought}"</p>}
                {todo.action.type === 'SCRAPE' && <p className="text-sm text-gray-400">Target: {todo.action.payload.url}</p>}
                {todo.action.type === 'ANALYZE_IMAGE' && <p className="text-sm text-gray-400">Analyzing image...</p>}
                {todo.action.type === 'PROCESS_ATTACHMENT' && <p className="text-sm text-gray-400">Processing: {todo.action.payload.attachment.name}</p>}
                {todo.action.type === 'API_CALL' && (
                    <p className="text-sm text-gray-400 font-mono">
                        <span className={`px-1.5 py-0.5 rounded text-xs ${
                            todo.action.payload.method === 'GET' ? 'bg-blue-600' :
                            todo.action.payload.method === 'POST' ? 'bg-green-600' :
                            todo.action.payload.method === 'PUT' ? 'bg-yellow-600 text-black' :
                            'bg-red-600'
                        }`}>{todo.action.payload.method}</span>
                        <span className="ml-2">{todo.action.payload.endpoint}</span>
                    </p>
                )}
            </div>
            <div className="flex items-center space-x-2">
                {getStatusIcon(todo.status)}
                <span className="text-sm text-gray-400 capitalize w-20 text-right">{todo.status.replace('-', ' ')}</span>
            </div>
        </>
    );

    if (isApiCall) {
        return (
            <li className="block">
                 <button 
                    onClick={() => onEditApiCall(todo)} 
                    disabled={todo.status !== 'pending'}
                    className="w-full flex items-start space-x-4 py-3 px-2 rounded-md transition-colors duration-200 disabled:cursor-not-allowed disabled:bg-gray-800/20 hover:bg-gray-700/50"
                >
                   {content}
                </button>
            </li>
        )
    }

    return <li className="flex items-start space-x-4 py-3 px-2">{content}</li>;
};

interface ChatViewProps {
  messages: ChatMessage[];
  onSendMessage: (message: string, image: File | null, attachment: File | null) => void;
  isProcessing: boolean;
  isRecording: boolean;
  hasActiveVlmUnits: boolean;
  hasDocumentAnalyzer: boolean;
  onToggleRecording: () => void;
  onPlayAudio: (text: string) => void;
  onEditApiCall: (todo: ToDo) => void;
}

const ChatView: React.FC<ChatViewProps> = ({ 
  messages, 
  onSendMessage, 
  isProcessing,
  isRecording,
  hasActiveVlmUnits,
  hasDocumentAnalyzer,
  onToggleRecording,
  onPlayAudio,
  onEditApiCall
}) => {
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);
  const attachmentInputRef = useRef<HTMLInputElement>(null);
  const [input, setInput] = useState('');
  const [stagedImage, setStagedImage] = useState<File | null>(null);
  const [stagedImageUrl, setStagedImageUrl] = useState<string | null>(null);
  const [stagedAttachment, setStagedAttachment] = useState<File | null>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(scrollToBottom, [messages]);
  
  useEffect(() => {
    if (stagedImage) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setStagedImageUrl(reader.result as string);
      };
      reader.readAsDataURL(stagedImage);
    } else {
      setStagedImageUrl(null);
    }
  }, [stagedImage]);


  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if ((input.trim() || stagedImage || stagedAttachment) && !isProcessing) {
      onSendMessage(input.trim(), stagedImage, stagedAttachment);
      setInput('');
      setStagedImage(null);
      setStagedImageUrl(null);
      setStagedAttachment(null);
    }
  };
  
  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setStagedImage(e.target.files[0]);
    }
  };

  const handleAttachmentSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
        setStagedAttachment(e.target.files[0]);
    }
  }

  const removeStagedImage = () => {
    setStagedImage(null);
    setStagedImageUrl(null);
    if(imageInputRef.current) {
        imageInputRef.current.value = "";
    }
  }

  const removeStagedAttachment = () => {
    setStagedAttachment(null);
    if(attachmentInputRef.current) {
        attachmentInputRef.current.value = "";
    }
  }

  const getMessageStyle = (sender: ChatMessage['sender']) => {
    switch (sender) {
      case 'user':
        return 'bg-primary self-end text-white';
      case 'ai':
        return 'bg-secondary-light self-start text-gray-200';
      case 'system':
        return 'bg-transparent text-center self-center text-gray-400 text-sm italic';
      case 'todo_list':
        return 'bg-secondary-light self-start w-full max-w-2xl';
    }
  };

  return (
    <div className="flex flex-col h-full bg-dark text-white">
      <header className="px-6 py-4 border-b border-gray-700">
        <h2 className="text-xl font-semibold">Chat Coalition</h2>
      </header>
      <main className="flex-1 p-6 overflow-y-auto">
        <div className="flex flex-col space-y-2">
          {messages.map((msg) => (
            <div key={msg.id} className={`flex items-end gap-2 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                {msg.sender === 'ai' && (
                  <button 
                    onClick={() => onPlayAudio(msg.text)} 
                    className="p-1 text-gray-400 rounded-full hover:bg-gray-700 hover:text-white transition-colors"
                    aria-label="Play audio"
                  >
                    <SpeakerWaveIcon className="w-5 h-5"/>
                  </button>
                )}
                <div className={`p-3 rounded-lg max-w-xl ${getMessageStyle(msg.sender)}`}>
                  {msg.sender === 'todo_list' && msg.todos ? (
                    <div>
                      <h4 className="font-semibold text-white mb-2">{msg.text}</h4>
                      <ul className="divide-y divide-gray-700">
                        {msg.todos.map(todo => <ToDoListItem key={todo.id} todo={todo} onEditApiCall={onEditApiCall} />)}
                      </ul>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {msg.image && <img src={msg.image} alt="User upload" className="rounded-lg max-w-xs max-h-64 object-contain" />}
                      {msg.attachment && (
                        <div className="flex items-center space-x-2 bg-gray-900/50 p-2 rounded-md border border-gray-600">
                           <DocumentTextIcon className="w-6 h-6 text-gray-400 flex-shrink-0"/>
                           <span className="text-sm text-gray-300 truncate">{msg.attachment.name}</span>
                        </div>
                      )}
                      {msg.text && <p className="whitespace-pre-wrap">{msg.text}</p>}
                    </div>
                  )}
                </div>
            </div>
          ))}
          {isProcessing && (
             <div className="self-start flex items-center space-x-2">
                <div className="bg-secondary-light p-3 rounded-lg">
                    <div className="flex items-center justify-center space-x-2">
                        <div className="w-2 h-2 rounded-full bg-gray-400 animate-pulse [animation-delay:-0.3s]"></div>
                        <div className="w-2 h-2 rounded-full bg-gray-400 animate-pulse [animation-delay:-0.15s]"></div>
                        <div className="w-2 h-2 rounded-full bg-gray-400 animate-pulse"></div>
                    </div>
                </div>
             </div>
          )}
          <div ref={messagesEndRef} />
        </div>
        {messages.length === 0 && !isProcessing && (
             <div className="flex flex-col items-center justify-center h-full text-gray-500">
                <ChatBubbleIcon className="w-16 h-16 mb-4"/>
                <h3 className="text-lg">AIX</h3>
                <p>Send a message to start the coalition process.</p>
            </div>
        )}
      </main>
      <footer className="p-4 border-t border-gray-700">
        <div className="flex items-center space-x-2 mb-2">
            {stagedImageUrl && (
                <div className="relative w-24 h-24 p-1 border border-gray-600 rounded-lg">
                    <img src={stagedImageUrl} alt="Staged preview" className="w-full h-full object-cover rounded"/>
                    <button onClick={removeStagedImage} className="absolute -top-2 -right-2 bg-red-600 text-white rounded-full p-0.5 hover:bg-red-700">
                        <XMarkIcon className="w-4 h-4"/>
                    </button>
                </div>
            )}
            {stagedAttachment && (
                 <div className="relative flex items-center space-x-2 bg-secondary-light p-2 rounded-lg border border-gray-600">
                    <DocumentTextIcon className="w-6 h-6 text-gray-400 flex-shrink-0"/>
                    <span className="text-sm text-gray-300 truncate">{stagedAttachment.name}</span>
                    <button onClick={removeStagedAttachment} className="ml-2 text-gray-400 hover:text-white">
                        <XMarkIcon className="w-4 h-4"/>
                    </button>
                </div>
            )}
        </div>
        <form onSubmit={handleSend} className="flex items-center space-x-4">
          <input type="file" ref={imageInputRef} onChange={handleImageSelect} accept="image/jpeg, image/png" className="hidden"/>
          <input type="file" ref={attachmentInputRef} onChange={handleAttachmentSelect} accept=".txt,.pdf,.doc,.docx" className="hidden"/>

          <div className="flex items-center space-x-2">
            {hasActiveVlmUnits && (
              <button
                  type="button"
                  onClick={() => imageInputRef.current?.click()}
                  className="p-2 rounded-full bg-secondary-light text-gray-300 hover:bg-gray-600 transition-colors"
                  aria-label="Upload image"
              >
                  <PhotoIcon className="w-6 h-6" />
              </button>
            )}
            {hasDocumentAnalyzer && (
               <button
                  type="button"
                  onClick={() => attachmentInputRef.current?.click()}
                  className="p-2 rounded-full bg-secondary-light text-gray-300 hover:bg-gray-600 transition-colors"
                  aria-label="Upload document"
              >
                  <PaperClipIcon className="w-6 h-6" />
              </button>
            )}
          </div>
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Send a message to the coalition..."
            className="flex-1 px-4 py-2 bg-secondary-light border border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary disabled:bg-gray-800"
            disabled={isProcessing}
          />
          <button
            type="button"
            onClick={onToggleRecording}
            className={`p-2 rounded-full transition-colors ${
              isRecording 
                ? 'bg-red-500 text-white animate-pulse' 
                : 'bg-secondary-light text-gray-300 hover:bg-gray-600'
            }`}
          >
            <MicrophoneIcon className="w-6 h-6" />
          </button>
          <button
            type="submit"
            className="px-6 py-2 font-semibold text-white bg-primary rounded-lg hover:bg-primary-hover disabled:bg-gray-500 disabled:cursor-not-allowed transition-colors"
            disabled={isProcessing || (!input.trim() && !stagedImage && !stagedAttachment)}
          >
            Send
          </button>
        </form>
      </footer>
    </div>
  );
};

export default ChatView;