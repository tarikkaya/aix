import React from 'react';
import { VECTOR_DATABASES } from '../lib/constants';

interface DataSourceEditorProps {
    title: string;
    provider: string;
    settings: any;
    onProviderChange: (newProvider: string, newSettings: any) => void;
    onSettingsChange: (newSettings: any) => void;
}

const formatLabel = (str: string) => {
    const spaced = str.replace(/([A-Z])/g, ' $1');
    return spaced.charAt(0).toUpperCase() + spaced.slice(1);
}

const DataSourceEditor: React.FC<DataSourceEditorProps> = ({
    title,
    provider,
    settings,
    onProviderChange,
    onSettingsChange,
}) => {
    const selectedProvider = VECTOR_DATABASES.find(p => p.value === provider) || VECTOR_DATABASES[0];

    const handleProviderSelect = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const newProviderValue = e.target.value;
        const newProvider = VECTOR_DATABASES.find(p => p.value === newProviderValue) || VECTOR_DATABASES[0];
        // Reset settings for the new provider
        const defaultSettings = newProvider.fields.reduce((acc, field) => ({ ...acc, [field.name]: '' }), {});
        onProviderChange(newProviderValue, defaultSettings);
    };

    const handleSettingInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        onSettingsChange({ ...settings, [e.target.name]: e.target.value });
    };

    return (
        <div className="border-t border-gray-700 pt-4 mt-4">
            <h4 className="text-md font-semibold text-white mb-2">{title}</h4>
            <div className="space-y-4">
                <div>
                    <label className="block text-sm font-medium text-gray-300">Provider</label>
                    <select
                        value={provider}
                        onChange={handleProviderSelect}
                        className="mt-1 block w-full bg-secondary-light border border-gray-600 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
                    >
                        {VECTOR_DATABASES.map(p => <option key={p.value} value={p.value}>{p.name}</option>)}
                    </select>
                </div>
                {selectedProvider.fields.map(field => (
                    <div key={field.name}>
                        <label htmlFor={field.name} className="block text-sm font-medium text-gray-300">{formatLabel(field.name)}</label>
                        <input
                            id={field.name}
                            type={field.type || 'text'}
                            name={field.name}
                            value={settings[field.name] || ''}
                            onChange={handleSettingInputChange}
                            placeholder={field.placeholder}
                            className="mt-1 block w-full bg-secondary-light border border-gray-600 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
                        />
                    </div>
                ))}
            </div>
        </div>
    );
};

export default DataSourceEditor;