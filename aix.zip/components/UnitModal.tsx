import React, { useState, useEffect } from 'react';
import { Unit, KnowledgeBase } from '../types';
import DataSourceEditor from './DataSourceEditor';
import ApiToolEditor from './ApiToolEditor';

interface UnitModalProps {
  unit: Unit | null;
  onSave: (unit: Unit) => void;
  onClose: () => void;
  models: string[];
  knowledgeBases: KnowledgeBase[];
}

const UnitModal: React.FC<UnitModalProps> = ({ unit, onSave, onClose, models, knowledgeBases }) => {
  const [formData, setFormData] = useState<Unit | null>(null);

  useEffect(() => {
    if (unit) {
      setFormData({ ...unit });
    }
  }, [unit]);

  if (!unit || !formData) return null;

  const isTool = formData.type === 'api_tool';

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    if (type === 'checkbox') {
        const { checked } = e.target as HTMLInputElement;
        setFormData({ ...formData, [name]: checked });
    } else {
        setFormData({ ...formData, [name]: value });
    }
  };

  const handleDataSourceChange = (
      type: 'knowledge' | 'experience',
      provider: string,
      settings: any,
  ) => {
    setFormData(prev => {
        if (!prev) return null;
        return {
            ...prev,
            [`${type}Provider`]: provider,
            [`${type}Settings`]: settings,
        };
    });
  };

  const handleSave = () => {
    if (formData) {
        onSave(formData);
    }
  };
  
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-75 transition-opacity">
      <div className="bg-secondary rounded-lg shadow-xl w-full max-w-2xl m-4 max-h-[90vh] flex flex-col">
        <div className="px-6 py-4 border-b border-gray-700">
          <h3 className="text-lg leading-6 font-medium text-white">Edit Unit: {unit.label}</h3>
        </div>
        <div className="p-6 space-y-4 overflow-y-auto">
          <div className="flex items-center justify-between">
            <label htmlFor="enabled" className="block text-sm font-medium text-gray-300">Enabled</label>
            <div className="relative inline-block w-10 mr-2 align-middle select-none transition duration-200 ease-in">
                <input type="checkbox" name="enabled" id="enabled" checked={formData.enabled} onChange={handleChange} className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer"/>
                <label htmlFor="enabled" className="toggle-label block overflow-hidden h-6 rounded-full bg-gray-500 cursor-pointer"></label>
            </div>
            <style>{`.toggle-checkbox:checked { right: 0; border-color: #4f46e5; } .toggle-checkbox:checked + .toggle-label { background-color: #4f46e5; }`}</style>
          </div>
          <div>
            <label htmlFor="label" className="block text-sm font-medium text-gray-300">Label</label>
            <input type="text" name="label" id="label" value={formData.label} onChange={handleChange} className="mt-1 block w-full bg-secondary-light border border-gray-600 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm" />
          </div>

          {isTool && (
              <ApiToolEditor
                payload={formData.apiToolPayload || { method: 'GET', endpoint: '' }}
                onPayloadChange={(payload) => setFormData(prev => prev ? ({ ...prev, apiToolPayload: payload }) : null)}
              />
          )}
          
          <div className="space-y-4 pt-4 border-t border-gray-700">
            {formData.type === 'rag' && (
                <div>
                  <label htmlFor="knowledgeBaseId" className="block text-sm font-medium text-gray-300">Knowledge Base</label>
                  <select name="knowledgeBaseId" id="knowledgeBaseId" value={formData.knowledgeBaseId || ''} onChange={handleChange} className="mt-1 block w-full bg-secondary-light border border-gray-600 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm">
                      <option value="">-- Select a Knowledge Base --</option>
                      {knowledgeBases.map(kb => <option key={kb.id} value={kb.id}>{kb.label}</option>)}
                  </select>
                  <p className="mt-2 text-xs text-gray-400">Link this RAG unit to a configured knowledge base.</p>
                </div>
            )}

            <div>
              <label htmlFor="model" className="block text-sm font-medium text-gray-300">Model</label>
              <select name="model" id="model" value={formData.model} onChange={handleChange} className="mt-1 block w-full bg-secondary-light border border-gray-600 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm">
                  {models.length > 0 ? (
                      models.map(m => <option key={m} value={m}>{m}</option>)
                  ) : (
                      <option value="">Provider has no selectable models</option>
                  )}
              </select>
            </div>
            <div>
              <label htmlFor="prompt" className="block text-sm font-medium text-gray-300">Prompt</label>
              <textarea name="prompt" id="prompt" rows={5} value={formData.prompt} onChange={handleChange} className="mt-1 block w-full bg-secondary-light border border-gray-600 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm" />
            </div>

            <DataSourceEditor
              title="Knowledge Source (Unit-Specific)"
              provider={formData.knowledgeProvider}
              settings={formData.knowledgeSettings}
              onProviderChange={(newProvider, newSettings) => handleDataSourceChange('knowledge', newProvider, newSettings)}
              onSettingsChange={(newSettings) => handleDataSourceChange('knowledge', formData.knowledgeProvider, newSettings)}
            />

              <DataSourceEditor
              title="Experience Source (Unit-Specific)"
              provider={formData.experienceProvider}
              settings={formData.experienceSettings}
              onProviderChange={(newProvider, newSettings) => handleDataSourceChange('experience', newProvider, newSettings)}
              onSettingsChange={(newSettings) => handleDataSourceChange('experience', formData.experienceProvider, newSettings)}
            />
          </div>
        </div>
        <div className="px-6 py-4 bg-dark-light border-t border-gray-700 flex justify-end space-x-3 rounded-b-lg">
          <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-gray-300 bg-secondary-light border border-gray-600 rounded-md shadow-sm hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-dark-light focus:ring-primary">Cancel</button>
          <button type="button" onClick={handleSave} className="px-4 py-2 text-sm font-medium text-white bg-primary border border-transparent rounded-md shadow-sm hover:bg-primary-hover focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-dark-light focus:ring-primary">Save Changes</button>
        </div>
      </div>
    </div>
  );
};

export default UnitModal;