

import React, { useState, useEffect, useMemo } from 'react';
import { Unit, LLMProvider, KnowledgeBase, STTProvider, TTSProvider } from '../types';
import { LLM_PROVIDERS, EMBEDDING_PROVIDERS, STT_PROVIDERS, TTS_PROVIDERS } from '../lib/constants';
import DataSourceEditor from './DataSourceEditor';
import { MicrophoneIcon, SpeakerWaveIcon } from './icons';

interface SettingsViewProps {
    managerPrompt: string;
    onSaveManagerPrompt: (prompt: string) => void;
    trainerUnit: Unit;
    onSaveTrainerSettings: (settings: Omit<Unit, 'id' | 'label' | 'enabled' | 'model'| 'type' | 'knowledgeBaseId' | 'isTrainer' | 'coalition' | 'apiToolPayload'>) => void;
    
    llmProvider: string;
    llmProviderSettings: any;
    onSaveLLMProviderSettings: (provider: string, settings: any) => void;

    sttProvider: string;
    sttProviderSettings: any;
    onSaveSTTProviderSettings: (provider: string, settings: any) => void;
    
    ttsProvider: string;
    ttsProviderSettings: any;
    onSaveTTSProviderSettings: (provider: string, settings: any) => void;

    knowledgeBases: KnowledgeBase[];
    onSaveKnowledgeBaseSettings: (kb: KnowledgeBase) => void;

    availableMicrophones: MediaDeviceInfo[];
    selectedMicrophone: string;
    onSelectMicrophone: (deviceId: string) => void;
    pushToTalkKey: string;
    onSetPushToTalkKey: (key: string) => void;
}

const SettingsView: React.FC<SettingsViewProps> = ({
    managerPrompt,
    onSaveManagerPrompt,
    trainerUnit,
    onSaveTrainerSettings,
    llmProvider,
    llmProviderSettings,
    onSaveLLMProviderSettings,
    sttProvider,
    sttProviderSettings,
    onSaveSTTProviderSettings,
    ttsProvider,
    ttsProviderSettings,
    onSaveTTSProviderSettings,
    knowledgeBases,
    onSaveKnowledgeBaseSettings,
    availableMicrophones,
    selectedMicrophone,
    onSelectMicrophone,
    pushToTalkKey,
    onSetPushToTalkKey
}) => {
    // Manager State
    const [prompt, setPrompt] = useState(managerPrompt);
    const [managerSaved, setManagerSaved] = useState(false);

    // Trainer State
    const [trainerSettings, setTrainerSettings] = useState<Omit<Unit, 'id' | 'label' | 'enabled' | 'model' | 'type' | 'knowledgeBaseId' | 'isTrainer' | 'coalition' | 'apiToolPayload'>>(
        {
            prompt: trainerUnit.prompt,
            knowledgeProvider: trainerUnit.knowledgeProvider,
            knowledgeSettings: trainerUnit.knowledgeSettings,
            experienceProvider: trainerUnit.experienceProvider,
            experienceSettings: trainerUnit.experienceSettings
        }
    );
    const [trainerSaved, setTrainerSaved] = useState(false);
    
    // LLM Provider State
    const [selectedLLMProvider, setSelectedLLMProvider] = useState<LLMProvider>(LLM_PROVIDERS.find(p => p.value === llmProvider) || LLM_PROVIDERS[0]);
    const [currentLLMSettings, setCurrentLLMSettings] = useState(llmProviderSettings);
    const [llmSaved, setLlmSaved] = useState(false);

    // STT Provider State
    const [selectedSTTProvider, setSelectedSTTProvider] = useState<STTProvider>(STT_PROVIDERS.find(p => p.value === sttProvider) || STT_PROVIDERS[0]);
    const [currentSTTSettings, setCurrentSTTSettings] = useState(sttProviderSettings);
    const [sttSaved, setSttSaved] = useState(false);

    // TTS Provider State
    const [selectedTTSProvider, setSelectedTTSProvider] = useState<TTSProvider>(TTS_PROVIDERS.find(p => p.value === ttsProvider) || TTS_PROVIDERS[0]);
    const [currentTTSSettings, setCurrentTTSSettings] = useState(ttsProviderSettings);
    const [ttsSaved, setTtsSaved] = useState(false);

    // Knowledge Base Settings State
    const [selectedKbId, setSelectedKbId] = useState<string>('');
    const [kbFormData, setKbFormData] = useState<KnowledgeBase | null>(null);
    const [kbSaved, setKbSaved] = useState(false);
    
    // Voice & Audio State
    const [isSettingKey, setIsSettingKey] = useState(false);

    useEffect(() => { setPrompt(managerPrompt); }, [managerPrompt]);
    useEffect(() => {
        setTrainerSettings({
            prompt: trainerUnit.prompt,
            knowledgeProvider: trainerUnit.knowledgeProvider,
            knowledgeSettings: trainerUnit.knowledgeSettings,
            experienceProvider: trainerUnit.experienceProvider,
            experienceSettings: trainerUnit.experienceSettings
        });
    }, [trainerUnit]);

    useEffect(() => {
        setSelectedLLMProvider(LLM_PROVIDERS.find(p => p.value === llmProvider) || LLM_PROVIDERS[0]);
        setCurrentLLMSettings(llmProviderSettings);
    }, [llmProvider, llmProviderSettings]);

    useEffect(() => {
        setSelectedSTTProvider(STT_PROVIDERS.find(p => p.value === sttProvider) || STT_PROVIDERS[0]);
        setCurrentSTTSettings(sttProviderSettings);
    }, [sttProvider, sttProviderSettings]);

    useEffect(() => {
        setSelectedTTSProvider(TTS_PROVIDERS.find(p => p.value === ttsProvider) || TTS_PROVIDERS[0]);
        setCurrentTTSSettings(ttsProviderSettings);
    }, [ttsProvider, ttsProviderSettings]);


    useEffect(() => {
        if (selectedKbId) {
            const kb = knowledgeBases.find(k => k.id === selectedKbId);
            setKbFormData(kb ? {...kb} : null);
        } else {
            setKbFormData(null);
        }
    }, [selectedKbId, knowledgeBases]);


    const handleLLMProviderChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const newProvider = LLM_PROVIDERS.find(p => p.value === e.target.value) || LLM_PROVIDERS[0];
        setSelectedLLMProvider(newProvider);
        const newSettings = newProvider.fields.reduce((acc, field) => ({ ...acc, [field.name]: '' }), {});
        setCurrentLLMSettings(newSettings);
    };

    const handleLLMSettingChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setCurrentLLMSettings({ ...currentLLMSettings, [e.target.name]: e.target.value });
    };

    const handleSaveLLM = () => {
        onSaveLLMProviderSettings(selectedLLMProvider.value, currentLLMSettings);
        setLlmSaved(true);
        setTimeout(() => setLlmSaved(false), 2000);
    };

    const handleSTTProviderChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const newProvider = STT_PROVIDERS.find(p => p.value === e.target.value) || STT_PROVIDERS[0];
        setSelectedSTTProvider(newProvider);
        const newSettings = newProvider.fields.reduce((acc, field) => ({ ...acc, [field.name]: '' }), {});
        setCurrentSTTSettings(newSettings);
    };

    const handleSTTSettingChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setCurrentSTTSettings({ ...currentSTTSettings, [e.target.name]: e.target.value });
    };

    const handleSaveSTT = () => {
        onSaveSTTProviderSettings(selectedSTTProvider.value, currentSTTSettings);
        setSttSaved(true);
        setTimeout(() => setSttSaved(false), 2000);
    };

    const handleTTSProviderChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const newProvider = TTS_PROVIDERS.find(p => p.value === e.target.value) || TTS_PROVIDERS[0];
        setSelectedTTSProvider(newProvider);
        const newSettings = newProvider.fields.reduce((acc, field) => ({ ...acc, [field.name]: '' }), {});
        setCurrentTTSSettings(newSettings);
    };

    const handleTTSSettingChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setCurrentTTSSettings({ ...currentTTSSettings, [e.target.name]: e.target.value });
    };

    const handleSaveTTS = () => {
        onSaveTTSProviderSettings(selectedTTSProvider.value, currentTTSSettings);
        setTtsSaved(true);
        setTimeout(() => setTtsSaved(false), 2000);
    };
    
    const handleManagerSave = () => {
        onSaveManagerPrompt(prompt);
        setManagerSaved(true);
        setTimeout(() => setManagerSaved(false), 2000);
    };
    
    const handleTrainerSave = () => {
        onSaveTrainerSettings(trainerSettings);
        setTrainerSaved(true);
        setTimeout(() => setTrainerSaved(false), 2000);
    };
    
    const handleKbFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        if (!kbFormData) return;
        const { name, value, type } = e.target;
        let finalValue: string | number = value;
        if (type === 'number') {
            finalValue = Number(value);
        }
        setKbFormData({ ...kbFormData, [name]: finalValue });
    };

    const handleKbEmbeddingProviderChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        if (!kbFormData) return;
        const newProvider = EMBEDDING_PROVIDERS.find(p => p.value === e.target.value) || EMBEDDING_PROVIDERS[0];
        const newSettings = newProvider.fields.reduce((acc, field) => ({ ...acc, [field.name]: '' }), {});
        setKbFormData({
            ...kbFormData,
            embeddingProvider: newProvider.value,
            embeddingProviderSettings: newSettings,
            embeddingModel: newProvider.models?.[0] || ''
        });
    };
    
    const handleKbEmbeddingSettingChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (!kbFormData) return;
        const { name, value } = e.target;
        setKbFormData({
            ...kbFormData,
            embeddingProviderSettings: {
                ...kbFormData.embeddingProviderSettings,
                [name]: value
            }
        });
    };

    const handleSaveKbSettings = () => {
        if (kbFormData) {
            onSaveKnowledgeBaseSettings(kbFormData);
            setKbSaved(true);
            setTimeout(() => setKbSaved(false), 2000);
        }
    };

    const selectedEmbeddingProvider = useMemo(() => {
        if (!kbFormData) return null;
        return EMBEDDING_PROVIDERS.find(p => p.value === kbFormData.embeddingProvider) || EMBEDDING_PROVIDERS[0];
    }, [kbFormData]);

    const handleTrainerPromptChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
         setTrainerSettings(prev => ({ ...prev, prompt: e.target.value }));
    }

    const handleTrainerDataSourceChange = (
        type: 'knowledge' | 'experience',
        provider: string,
        settings: any
    ) => {
        setTrainerSettings(prev => ({
            ...prev,
            [`${type}Provider`]: provider,
            [`${type}Settings`]: settings,
        }));
    };
    
    useEffect(() => {
      if (!isSettingKey) return;
      const handleKeyDown = (e: KeyboardEvent) => {
        e.preventDefault();
        onSetPushToTalkKey(e.key === ' ' ? 'Space' : e.key);
        setIsSettingKey(false);
      };
      window.addEventListener('keydown', handleKeyDown, { once: true });
      return () => {
        window.removeEventListener('keydown', handleKeyDown);
      };
    }, [isSettingKey, onSetPushToTalkKey]);


    return (
        <div className="flex flex-col h-full bg-dark text-white">
            <header className="px-6 py-4 border-b border-gray-700">
                <h2 className="text-xl font-semibold">Settings</h2>
            </header>
            <main className="flex-1 p-6 overflow-y-auto">
                <div className="max-w-4xl mx-auto space-y-8">
                    {/* LLM Provider Settings */}
                    <div className="bg-secondary p-6 rounded-lg shadow-lg">
                        <h3 className="text-lg font-medium text-white mb-1">LLM Preference</h3>
                        <p className="text-sm text-gray-400 mb-4">Choose and configure your preferred Large Language Model provider for chat and reasoning.</p>
                        <div className="space-y-4">
                            <select
                                value={selectedLLMProvider.value}
                                onChange={handleLLMProviderChange}
                                className="w-full p-3 bg-secondary-light border border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-primary sm:text-sm"
                            >
                                {LLM_PROVIDERS.map(p => <option key={p.value} value={p.value}>{p.name}</option>)}
                            </select>
                            {selectedLLMProvider.fields.map(field => (
                                <div key={field.name}>
                                    <label className="capitalize block text-sm font-medium text-gray-300">{field.name.replace(/([A-Z])/g, ' $1')}</label>
                                    <input
                                        type={field.type}
                                        name={field.name}
                                        value={currentLLMSettings[field.name] || ''}
                                        onChange={handleLLMSettingChange}
                                        placeholder={field.placeholder}
                                        className="mt-1 block w-full bg-dark-light border border-gray-600 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
                                    />
                                </div>
                            ))}
                        </div>
                        <div className="mt-4 flex justify-end items-center">
                            {llmSaved && <span className="text-green-400 mr-4 text-sm">Saved!</span>}
                            <button onClick={handleSaveLLM} className="px-6 py-2 font-semibold text-white bg-primary rounded-lg hover:bg-primary-hover">Save LLM Settings</button>
                        </div>
                    </div>

                    {/* Speech-to-Text Preference */}
                    <div className="bg-secondary p-6 rounded-lg shadow-lg">
                        <div className="flex items-start space-x-3 mb-1">
                            <div>
                                <h3 className="text-lg font-medium text-white">Speech-to-Text Preference</h3>
                                <p className="text-sm text-gray-400 mt-1">If you are using an LLM that does not support voice-to-text, you will need to enter credentials for a dedicated Speech-to-Text service.</p>
                            </div>
                        </div>
                        <div className="space-y-4 mt-4">
                             <select
                                value={selectedSTTProvider.value}
                                onChange={handleSTTProviderChange}
                                className="w-full p-3 bg-secondary-light border border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-primary sm:text-sm"
                            >
                                {STT_PROVIDERS.map(p => <option key={p.value} value={p.value}>{p.name}</option>)}
                            </select>
                            {selectedSTTProvider.fields.map(field => (
                                <div key={field.name}>
                                    <label className="capitalize block text-sm font-medium text-gray-300">{field.name.replace(/([A-Z])/g, ' $1')}</label>
                                    <input
                                        type={field.type}
                                        name={field.name}
                                        value={currentSTTSettings[field.name] || ''}
                                        onChange={handleSTTSettingChange}
                                        placeholder={field.placeholder}
                                        className="mt-1 block w-full bg-dark-light border border-gray-600 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
                                    />
                                    {field.info && (
                                        <p className="mt-2 text-xs text-gray-400">{field.info} {field.infoLink && <a href={field.infoLink.url} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">{field.infoLink.text}</a>}</p>
                                    )}
                                </div>
                            ))}
                        </div>
                         <div className="mt-4 flex justify-end items-center">
                            {sttSaved && <span className="text-green-400 mr-4 text-sm">Saved!</span>}
                            <button onClick={handleSaveSTT} className="px-6 py-2 font-semibold text-white bg-primary rounded-lg hover:bg-primary-hover">Save STT Settings</button>
                        </div>
                    </div>

                    {/* Text-to-Speech Preference */}
                    <div className="bg-secondary p-6 rounded-lg shadow-lg">
                        <div className="flex items-start space-x-3 mb-1">
                           <SpeakerWaveIcon className="w-6 h-6 text-gray-400 mt-1" />
                           <div>
                                <h3 className="text-lg font-medium text-white">Text-to-Speech Preference</h3>
                                <p className="text-sm text-gray-400 mt-1">Configure a Text-to-Speech provider to read AI responses aloud.</p>
                            </div>
                        </div>
                        <div className="space-y-4 mt-4">
                             <select
                                value={selectedTTSProvider.value}
                                onChange={handleTTSProviderChange}
                                className="w-full p-3 bg-secondary-light border border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-primary sm:text-sm"
                            >
                                {TTS_PROVIDERS.map(p => <option key={p.value} value={p.value}>{p.name}</option>)}
                            </select>
                            {selectedTTSProvider.fields.map(field => (
                                <div key={field.name}>
                                    <label className="capitalize block text-sm font-medium text-gray-300">{field.name.replace(/([A-Z])/g, ' $1')}</label>
                                    <input
                                        type={field.type}
                                        name={field.name}
                                        value={currentTTSSettings[field.name] || ''}
                                        onChange={handleTTSSettingChange}
                                        placeholder={field.placeholder}
                                        className="mt-1 block w-full bg-dark-light border border-gray-600 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
                                    />
                                    {field.info && (
                                        <p className="mt-2 text-xs text-gray-400">{field.info} {field.infoLink && <a href={field.infoLink.url} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">{field.infoLink.text}</a>}</p>
                                    )}
                                </div>
                            ))}
                        </div>
                         <div className="mt-4 flex justify-end items-center">
                            {ttsSaved && <span className="text-green-400 mr-4 text-sm">Saved!</span>}
                            <button onClick={handleSaveTTS} className="px-6 py-2 font-semibold text-white bg-primary rounded-lg hover:bg-primary-hover">Save TTS Settings</button>
                        </div>
                    </div>
                     
                    {/* Voice & Audio Settings */}
                    <div className="bg-secondary p-6 rounded-lg shadow-lg">
                      <div className="flex items-start space-x-3 mb-1">
                        <MicrophoneIcon className="w-6 h-6 text-gray-400 mt-1" />
                        <div>
                            <h3 className="text-lg font-medium text-white">Voice & Audio</h3>
                            <p className="text-sm text-gray-400 mt-1">Configure your microphone and push-to-talk settings.</p>
                        </div>
                      </div>
                      <div className="space-y-4 mt-4">
                          <div>
                              <label htmlFor="microphone" className="block text-sm font-medium text-gray-300">Input Device (Microphone)</label>
                              <select
                                  id="microphone"
                                  value={selectedMicrophone}
                                  onChange={(e) => onSelectMicrophone(e.target.value)}
                                  className="mt-1 w-full p-3 bg-secondary-light border border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-primary sm:text-sm"
                              >
                                  {availableMicrophones.length > 0 ? (
                                      availableMicrophones.map(device => (
                                          <option key={device.deviceId} value={device.deviceId}>{device.label || device.deviceId}</option>
                                      ))
                                  ) : (
                                      <option>No microphones found. Please grant permission.</option>
                                  )}
                              </select>
                          </div>
                          <div>
                              <label className="block text-sm font-medium text-gray-300">Push to Talk Hotkey</label>
                              <button
                                  onClick={() => setIsSettingKey(true)}
                                  className="mt-1 w-full text-left p-3 bg-secondary-light border border-gray-600 rounded-md hover:border-primary"
                              >
                                  {isSettingKey ? 'Press any key...' : (pushToTalkKey ? <kbd className="px-2 py-1.5 text-xs font-semibold text-gray-800 bg-gray-100 border border-gray-200 rounded-lg">{pushToTalkKey}</kbd> : 'Click to set hotkey')}
                              </button>
                          </div>
                      </div>
                  </div>


                     {/* Knowledge Base Specific Settings */}
                    <div className="bg-secondary p-6 rounded-lg shadow-lg">
                        <h3 className="text-lg font-medium text-white mb-1">Knowledge Base Specific Settings</h3>
                        <p className="text-sm text-gray-400 mb-4">Select a Knowledge Base to configure its unique embedding and chunking settings.</p>
                        <select
                            value={selectedKbId}
                            onChange={(e) => setSelectedKbId(e.target.value)}
                            className="w-full p-3 bg-secondary-light border border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-primary sm:text-sm"
                        >
                            <option value="">-- Select a Knowledge Base --</option>
                            {knowledgeBases.map(kb => <option key={kb.id} value={kb.id}>{kb.label}</option>)}
                        </select>
                        
                        {kbFormData && selectedEmbeddingProvider && (
                             <div className="mt-6 space-y-6">
                                {/* Embedding Preference */}
                                <div className="border-t border-gray-700 pt-6">
                                    <h3 className="text-lg font-medium text-white mb-1">Embedding Preference</h3>
                                    <p className="text-sm text-gray-400 mb-4">Configure the embedding provider and model for this specific knowledge base.</p>
                                    <div className="space-y-4">
                                        <div>
                                            <label className="block text-sm font-medium text-gray-300">Embedding Provider</label>
                                            <select
                                                value={kbFormData.embeddingProvider}
                                                onChange={handleKbEmbeddingProviderChange}
                                                className="mt-1 w-full p-3 bg-secondary-light border border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-primary sm:text-sm"
                                            >
                                                {EMBEDDING_PROVIDERS.map(p => <option key={p.value} value={p.value}>{p.name}</option>)}
                                            </select>
                                        </div>
                                        
                                        {selectedEmbeddingProvider.fields.map(field => (
                                            <div key={field.name}>
                                                <label className="capitalize block text-sm font-medium text-gray-300">{field.name.replace(/([A-Z])/g, ' $1')}</label>
                                                <input
                                                    type={field.type}
                                                    name={field.name}
                                                    value={kbFormData.embeddingProviderSettings[field.name] || ''}
                                                    onChange={handleKbEmbeddingSettingChange}
                                                    placeholder={field.placeholder}
                                                    className="mt-1 block w-full bg-dark-light border border-gray-600 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
                                                />
                                                {field.info && <p className="mt-2 text-xs text-gray-400">{field.info}</p>}
                                            </div>
                                        ))}

                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                            <div>
                                                <label className="block text-sm font-medium text-gray-300">Embedding Model</label>
                                                {selectedEmbeddingProvider.models.length > 0 ? (
                                                    <select
                                                        name="embeddingModel"
                                                        value={kbFormData.embeddingModel}
                                                        onChange={handleKbFormChange}
                                                        className="mt-1 w-full p-3 bg-secondary-light border border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-primary sm:text-sm"
                                                    >
                                                        {selectedEmbeddingProvider.models.map(m => <option key={m} value={m}>{m}</option>)}
                                                    </select>
                                                ) : (
                                                    <input
                                                        type="text"
                                                        name="embeddingModel"
                                                        value={kbFormData.embeddingModel}
                                                        onChange={handleKbFormChange}
                                                        placeholder="Enter model name (e.g. nomic-embed-text)"
                                                        className="mt-1 block w-full bg-dark-light border border-gray-600 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
                                                    />
                                                )}
                                            </div>
                                            <div>
                                                <label className="block text-sm font-medium text-gray-300">Max Embedding Chunk Length</label>
                                                <input
                                                    type="number"
                                                    name="embeddingChunkSize"
                                                    value={kbFormData.embeddingChunkSize}
                                                    onChange={handleKbFormChange}
                                                    className="mt-1 block w-full bg-dark-light border border-gray-600 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                {/* Text Splitting & Chunking Preferences */}
                                <div className="border-t border-gray-700 pt-6">
                                    <h3 className="text-lg font-medium text-white mb-1">Text Splitting & Chunking Preferences</h3>
                                    <p className="text-sm text-gray-400 mb-4">Define how documents are chunked before embedding for this knowledge base.</p>
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                        <div>
                                            <label className="block text-sm font-medium text-gray-300">Text Chunk Size</label>
                                            <input
                                                type="number"
                                                name="chunkSize"
                                                value={kbFormData.chunkSize}
                                                onChange={handleKbFormChange}
                                                className="mt-1 block w-full bg-dark-light border border-gray-600 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
                                            />
                                            <p className="mt-2 text-xs text-gray-400">Max characters in a single vector.</p>
                                        </div>
                                        <div>
                                            <label className="block text-sm font-medium text-gray-300">Text Chunk Overlap</label>
                                            <input
                                                type="number"
                                                name="chunkOverlap"
                                                value={kbFormData.chunkOverlap}
                                                onChange={handleKbFormChange}
                                                className="mt-1 block w-full bg-dark-light border border-gray-600 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
                                            />
                                            <p className="mt-2 text-xs text-gray-400">Character overlap between chunks.</p>
                                        </div>
                                    </div>
                                </div>
                                <div className="mt-4 flex justify-end items-center">
                                    {kbSaved && <span className="text-green-400 mr-4 text-sm">Saved!</span>}
                                    <button onClick={handleSaveKbSettings} className="px-6 py-2 font-semibold text-white bg-primary rounded-lg hover:bg-primary-hover">Save Knowledge Base Settings</button>
                                </div>
                             </div>
                        )}
                    </div>

                    {/* Manager and Trainer Settings */}
                    <div className="bg-secondary p-6 rounded-lg shadow-lg">
                        <h3 className="text-lg font-medium text-white mb-1">Coalition Manager Strategy</h3>
                        <p className="text-sm text-gray-400 mb-4">Define the high-level strategy for the Manager Unit.</p>
                        <textarea value={prompt} onChange={(e) => setPrompt(e.target.value)} rows={8} className="w-full p-3 bg-secondary-light border border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-primary sm:text-sm" />
                        <div className="mt-4 flex justify-end items-center">
                            {managerSaved && <span className="text-green-400 mr-4 text-sm">Saved!</span>}
                            <button onClick={handleManagerSave} className="px-6 py-2 font-semibold text-white bg-primary rounded-lg hover:bg-primary-hover">Save Strategy</button>
                        </div>
                    </div>
                    <div className="bg-secondary p-6 rounded-lg shadow-lg">
                        <h3 className="text-lg font-medium text-white mb-1">Trainer Configuration</h3>
                        <p className="text-sm text-gray-400 mb-4">Configure the system's Trainer, its core prompt, and data sources.</p>
                        <div className="space-y-4">
                            <div>
                               <label htmlFor="trainerPrompt" className="block text-sm font-medium text-gray-300">Trainer Prompt</label>
                                <textarea id="trainerPrompt" name="prompt" value={trainerSettings.prompt} onChange={handleTrainerPromptChange} rows={5} className="mt-1 w-full p-3 bg-secondary-light border border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-primary sm:text-sm" />
                            </div>
                            <DataSourceEditor 
                                title="Knowledge Source"
                                provider={trainerSettings.knowledgeProvider}
                                settings={trainerSettings.knowledgeSettings}
                                onProviderChange={(newProvider, newSettings) => handleTrainerDataSourceChange('knowledge', newProvider, newSettings)}
                                onSettingsChange={(newSettings) => handleTrainerDataSourceChange('knowledge', trainerSettings.knowledgeProvider, newSettings)}
                            />
                            <DataSourceEditor 
                                title="Experience Source"
                                provider={trainerSettings.experienceProvider}
                                settings={trainerSettings.experienceSettings}
                                onProviderChange={(newProvider, newSettings) => handleTrainerDataSourceChange('experience', newProvider, newSettings)}
                                onSettingsChange={(newSettings) => handleTrainerDataSourceChange('experience', trainerSettings.experienceProvider, newSettings)}
                            />
                        </div>
                        <div className="mt-4 flex justify-end items-center">
                            {trainerSaved && <span className="text-green-400 mr-4 text-sm">Saved!</span>}
                            <button onClick={handleTrainerSave} className="px-6 py-2 font-semibold text-white bg-primary rounded-lg hover:bg-primary-hover">Save Trainer Settings</button>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    );
};

export default SettingsView;